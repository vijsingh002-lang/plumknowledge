# Changelog

## 1.0.0 — Initial migration

- Rebuilt the WordPress "Plumpos Platform" knowledge base as a static Next.js 16 help center.
- Migrated 66 articles, 36 pages, 77 FAQs, 39 categories (23 with articles) and ~130 training videos from the WordPress database.
- Preserved existing `/slug/` URLs; added 205 redirects (old date permalinks, short category URLs, FAQ items, renamed/moved pages, retired WordPress endpoints).
- Excluded attacker-created content from the compromised source and removed all server-side code; every image re-encoded and all HTML sanitized. See docs/SECURITY.md.
- Features: global search (Ctrl-K + /search/), light/dark/system themes, per-article table of contents, related/prev-next, "was this helpful" feedback, video library, FAQ accordion, full SEO (metadata, canonical, Open Graph, JSON-LD, sitemap, robots).
