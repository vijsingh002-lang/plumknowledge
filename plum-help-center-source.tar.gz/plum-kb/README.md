# Plum Central Help Center

A modern, static help center rebuilt from the WordPress "Plumpos Platform" knowledge base. Built with Next.js 16, React 19, TypeScript and Tailwind CSS 4, and delivered as a fully static site.

- **No live WordPress, PHP, or database in production.** WordPress content is exported once, at build time, into sanitized JSON and pre-optimized images. The deployed site is plain HTML, CSS and JavaScript.
- **Content stays editable in WordPress.** Re-run the export whenever content changes (see below). This is a headless architecture, but the frontend depends on an export rather than a live connection, so the public site never needs WordPress to be reachable.

> **Security note.** The source WordPress install was compromised (webshell plugins, rogue admin accounts). This rebuild deliberately excludes all server-side code and the attacker-created content, and re-encodes every image. See `docs/SECURITY.md` and `docs/MIGRATION.md`.

## Requirements

- Node.js 20.9+ (Node 22 recommended)
- For the content export only: read access to a WordPress MySQL/MariaDB database and a copy of `wp-content/uploads`.

## Quick start (build from existing content)

The repository already contains an exported snapshot in `content/` and images in `public/media/`, so you can build the site without a database:

```bash
npm install
npm run dev        # http://localhost:3000
npm run build      # static export to ./out  (+ regenerates deploy/ redirect configs)
npm run start      # serve ./out locally to preview the production build
```

Other scripts:

```bash
npm run typecheck  # tsc --noEmit
npm run lint       # eslint
npm run format     # prettier --write
```

## Refreshing content from WordPress

Run this on a **trusted build machine**, never on the public web server, against a **clean** database (see `docs/SECURITY.md`).

1. Copy `.env.example` to `.env.local` and fill in the database connection and uploads path. Use a database user with **SELECT only** privileges.
2. Export, then build:

   ```bash
   npm run export:content   # writes content/*.json and public/media/*
   npm run build
   ```

3. Review `migration-report/` (see below), then deploy `./out`.

The exporter opens the database in read-only mode and never writes to it. It re-encodes every image through `sharp` (stripping metadata and any hidden payload) and passes all HTML through a strict allowlist sanitizer.

## Deployment

The build output in `./out` is static; host it on any static host or web server.

- **Static hosts** (S3 + CloudFront, Netlify, Vercel static, GitHub Pages, etc.): upload `./out`. Configure the redirects from `content/redirects.json` in your host's redirect mechanism, and set the security headers from `docs/DEPLOYMENT.md`.
- **Self-hosted nginx or Apache**: sample vhosts are in `deploy/nginx.conf` and `deploy/apache.conf`. They include the generated redirect maps (`deploy/redirects.*.conf`) and the recommended security headers, and disable PHP execution. See `docs/DEPLOYMENT.md`.

`npm run build` regenerates the redirect configs from `content/redirects.json`, so they never drift from the export.

## Architecture

```
WordPress (editing only, private)
        │   one-time / on-change
        ▼
scripts/export-wordpress.ts ── reads DB (SELECT-only) + wp-content/uploads
        │        • strips Fusion/Avada shortcodes and Google-Sites markup
        │        • sanitizes HTML against a strict allowlist
        │        • re-encodes images to responsive WebP
        │        • excludes attacker-created content
        ▼
content/*.json  +  public/media/*        (sanitized, validated at build time)
        ▼
Next.js 16 (App Router, output: "export")
        ▼
./out  — static HTML/CSS/JS  →  nginx / Apache / CDN
```

The content contract between the exporter and the app is defined once in `types/content.ts` (Zod schemas) and validated at build time in `lib/content.ts`, so a malformed export fails the build instead of shipping a broken page.

See `docs/ARCHITECTURE.md` for the folder layout and component map, `docs/MIGRATION.md` for the database mapping and URL redirects, and `docs/QA-CHECKLIST.md` for the test checklist.

## Project layout

```
app/                  routes (App Router)
components/           UI, grouped by area (layout, search, article, pages, ...)
content/              exported JSON (generated) — the site's data
hooks/                small client hooks
lib/                  data layer, ranking, SEO, formatting, analytics, config
public/media/         re-encoded images (generated)
scripts/              WordPress exporter and deploy-config generator
  wp/                 export pipeline modules (shortcodes, html, media, pages)
types/                shared content + search types (Zod schemas)
deploy/               nginx/Apache vhosts and generated redirect maps
docs/                 architecture, migration, security, deployment, QA
migration-report/     generated report from the last export
```

## Analytics

No analytics provider is hard-coded. Components emit provider-neutral events (`lib/analytics.ts`) to `window.dataLayer` and a `kb:analytics` DOM event. To enable Google Analytics 4, set `NEXT_PUBLIC_GA_MEASUREMENT_ID` and add the GA hosts to the CSP `script-src`, `connect-src` and `img-src` (see `docs/DEPLOYMENT.md`). The old site's MonsterInsights plugin was never connected to a GA property, so there is no historical data to preserve.
