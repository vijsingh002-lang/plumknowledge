import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { getAllEntryPaths, getEntryByPath } from "@/lib/content";
import { buildMetadata } from "@/lib/seo";
import { displayTitle } from "@/lib/site-config";
import { ArticleView } from "@/components/article/ArticleView";
import { PageView } from "@/components/pages/PageView";

// Every article and page URL from WordPress (/%postname%/), pre-rendered.
export const dynamicParams = false;
export function generateStaticParams() {
  return getAllEntryPaths().map((path) => ({ path }));
}

type Props = { params: Promise<{ path: string[] }> };

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const hit = getEntryByPath((await params).path);
  if (!hit) return {};
  if (hit.type === "article") {
    const a = hit.entry;
    return buildMetadata({ title: a.title, description: a.excerpt, path: a.url, type: "article", image: a.ogImage, publishedTime: a.publishedAt, modifiedTime: a.updatedAt });
  }
  const p = hit.entry;
  return buildMetadata({ title: displayTitle(p.title), description: p.excerpt || `${displayTitle(p.title)} in the Plum Central Help Center.`, path: p.url });
}

export default async function EntryPage({ params }: Props) {
  const hit = getEntryByPath((await params).path);
  if (!hit) notFound();
  return hit.type === "article" ? <ArticleView article={hit.entry} /> : <PageView page={hit.entry} />;
}
