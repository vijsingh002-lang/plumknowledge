import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { getArticlesInCategory, getCategories, getCategoryByPath, getCategoryTrail, getChildCategories } from "@/lib/content";
import { buildMetadata } from "@/lib/seo";
import { displayTitle, presentationFor } from "@/lib/site-config";
import { pluralize } from "@/lib/format";
import { Breadcrumbs } from "@/components/ui/Breadcrumbs";
import { CategoryIcon } from "@/components/ui/CategoryIcon";
import { toListItem } from "@/components/article/ArticleList";
import { CategoryArticles } from "@/components/category/CategoryArticles";
import { TrackView } from "@/components/article/TrackView";

// WordPress category URLs: /category/<parent>/<child>/. Empty categories redirect (see content/redirects.json).
export const dynamicParams = false;
export function generateStaticParams() {
  return getCategories().filter((c) => c.articleCount > 0).map((c) => ({ path: c.path }));
}

type Props = { params: Promise<{ path: string[] }> };

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const c = getCategoryByPath((await params).path);
  if (!c) return {};
  const description = c.description || presentationFor(c.path[0]).description || `${pluralize(c.articleCount, "article")} about ${displayTitle(c.name)}.`;
  return buildMetadata({ title: displayTitle(c.name), description, path: c.url });
}

export default async function CategoryPage({ params }: Props) {
  const category = getCategoryByPath((await params).path);
  if (!category) notFound();
  const trail = getCategoryTrail(category.id);
  const children = getChildCategories(category.id);
  const items = getArticlesInCategory(category.id).map(toListItem);
  const name = displayTitle(category.name);
  const description = category.description || (category.parentId ? "" : presentationFor(category.slug).description);

  return (
    <div className="mx-auto max-w-5xl px-4 pt-6 sm:px-6 lg:pt-10">
      <Breadcrumbs items={trail.map((c) => ({ name: displayTitle(c.name), url: c.url }))} />
      <header className="mt-6 flex items-start gap-4">
        <span className="mt-1 flex size-12 shrink-0 items-center justify-center rounded-xl bg-plum-wash text-plum">
          <CategoryIcon slug={trail[0]?.slug ?? category.slug} className="size-6" />
        </span>
        <div>
          <h1 className="font-display text-[2rem] font-bold leading-tight tracking-tight sm:text-[2.5rem]">{name}</h1>
          {description && <p className="mt-2 max-w-2xl text-lg text-ink-soft">{description}</p>}
          <p className="mt-2 text-sm text-ink-faint">{pluralize(category.articleCount, "article")}</p>
        </div>
      </header>

      {children.length > 0 && (
        <nav aria-label="Subcategories" className="mt-8">
          <ul className="flex flex-wrap gap-2">
            {children.map((c) => (
              <li key={c.id}>
                <Link href={c.url} className="inline-flex items-center gap-2 rounded-full border border-line bg-surface px-3.5 py-1.5 text-sm hover:border-plum hover:text-plum">
                  {displayTitle(c.name)}
                  <span className="text-ink-faint">{c.articleCount}</span>
                </Link>
              </li>
            ))}
          </ul>
        </nav>
      )}

      <section className="mt-8" aria-label="Articles">
        <CategoryArticles items={items} categoryName={name} />
      </section>
      <TrackView event={{ name: "category_opened", url: category.url, category: name }} />
    </div>
  );
}
