"use client";

import Link from "next/link";

/** Last-resort boundary: a rendering error shows this instead of a broken page. */
export default function ErrorPage({ reset }: { error: Error; reset: () => void }) {
  return (
    <div role="alert" className="mx-auto max-w-2xl px-4 py-20 sm:px-6">
      <h1 className="font-display text-3xl font-bold tracking-tight">This page couldn’t be displayed.</h1>
      <p className="mt-3 text-lg text-ink-soft">Reload to try again. If it keeps happening, go back to the help center home.</p>
      <div className="mt-6 flex gap-3">
        <button type="button" onClick={reset} className="rounded-xl bg-plum px-4 py-2 font-medium text-paper hover:bg-plum-strong">Try again</button>
        <Link href="/" className="rounded-xl border border-line-strong px-4 py-2 font-medium hover:border-plum">Help center home</Link>
      </div>
    </div>
  );
}
