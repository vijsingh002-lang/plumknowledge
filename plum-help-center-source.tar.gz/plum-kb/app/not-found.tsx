import Link from "next/link";
import { HeroSearch } from "@/components/home/Hero";

export default function NotFound() {
  return (
    <div className="mx-auto max-w-2xl px-4 py-20 sm:px-6">
      <p className="font-display text-6xl font-bold text-plum">404</p>
      <h1 className="mt-3 font-display text-3xl font-bold tracking-tight">This page doesn’t exist.</h1>
      <p className="mt-3 text-lg text-ink-soft">The link may be out of date. Search for the topic instead, or start from the help center home.</p>
      <div className="mt-8"><HeroSearch /></div>
      <Link href="/" className="mt-8 inline-block font-medium text-plum hover:underline">Go to the help center home</Link>
    </div>
  );
}
