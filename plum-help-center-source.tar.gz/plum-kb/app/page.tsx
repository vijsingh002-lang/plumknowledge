import Link from "next/link";
import { ChevronRight, CircleHelp, PlayCircle } from "lucide-react";
import { getArticles, getArticlesInCategory, getFaqs, getPageByUrl, getRecentlyUpdated, getTopCategories } from "@/lib/content";
import { getPopularArticles } from "@/lib/ranking";
import { BRAND, START_HERE_SLUGS, displayTitle, presentationFor } from "@/lib/site-config";
import { buildMetadata, jsonLd, websiteJsonLd } from "@/lib/seo";
import type { Page } from "@/types/content";
import { HeroSearch } from "@/components/home/Hero";
import { StartHereTicket } from "@/components/home/StartHereTicket";
import { CategoryDirectory } from "@/components/home/CategoryDirectory";
import { ArticleColumn } from "@/components/home/ArticleColumns";

export const metadata = buildMetadata({ title: BRAND.title, description: BRAND.description, path: "/" });

function countVideos(page: Page | undefined, seen = new Set<number>()): number {
  if (!page || seen.has(page.id)) return 0;
  seen.add(page.id);
  return page.blocks.reduce((n, b) => n + (b.kind === "videos" ? b.items.length : b.kind === "links" ? b.items.reduce((m, i) => m + countVideos(getPageByUrl(i.href), seen), 0) : 0), 0);
}

export default function HomePage() {
  const categories = getTopCategories().sort((a, b) => presentationFor(a.slug).order - presentationFor(b.slug).order);
  const gettingStarted = categories.find((c) => c.slug === "getting-started");
  const steps = START_HERE_SLUGS.map((s) => getArticles().find((a) => a.slug === s)).filter((a) => !!a);
  const products = categories.filter((c) => c !== gettingStarted).map((c) => ({ category: c, top: getArticlesInCategory(c.id).slice(0, 3) }));
  const trainingHub = getPageByUrl("/training-videos/");
  const videoSections = trainingHub?.blocks.flatMap((b) => (b.kind === "links" ? b.items : [])) ?? [];
  const faqs = getFaqs();

  return (
    <>
      {/* Hero */}
      <section className="relative overflow-hidden border-b border-line">
        <div className="dot-field absolute inset-0 [mask-image:linear-gradient(to_bottom,black,transparent_85%)]" aria-hidden="true" />
        <div className="relative mx-auto grid max-w-7xl items-center gap-12 px-4 py-14 sm:px-6 lg:grid-cols-[minmax(0,1.15fr)_minmax(0,1fr)] lg:py-20">
          <div>
            <h1 className="font-display text-[2.6rem] font-bold leading-[1.05] tracking-[-0.035em] sm:text-[3.4rem] lg:text-[3.9rem]">How can we help?</h1>
            <p className="mt-4 max-w-xl text-lg leading-relaxed text-ink-soft">
              Step-by-step guides, training videos and answers for every {BRAND.product} app, from the POS terminal to schedules and in-store music.
            </p>
            <div className="mt-8 max-w-xl"><HeroSearch /></div>
          </div>
          {gettingStarted && steps.length > 0 && <StartHereTicket steps={steps} categoryUrl={gettingStarted.url} />}
        </div>
      </section>

      <div className="mx-auto max-w-7xl px-4 sm:px-6">
        {/* Products */}
        <section aria-labelledby="products-title" className="pt-16">
          <div className="flex items-end justify-between gap-4">
            <h2 id="products-title" className="font-display text-2xl font-bold sm:text-3xl">Browse by product</h2>
            <p className="hidden text-sm text-ink-faint sm:block">{getArticles().length} articles in {products.length} sections</p>
          </div>
          <div className="mt-6"><CategoryDirectory entries={products} /></div>
        </section>

        {/* Popular + recent */}
        <div className="grid gap-12 pt-16 md:grid-cols-2">
          <ArticleColumn title="Popular articles" note="Most referenced across the help center" articles={getPopularArticles(6)} />
          <ArticleColumn title="Recently updated" articles={getRecentlyUpdated(6)} dated />
        </div>

        {/* Videos + FAQ */}
        <div className="grid gap-6 pt-16 lg:grid-cols-[1.4fr_1fr]">
          {trainingHub && (
            <section aria-labelledby="videos-title" className="rounded-2xl border border-line bg-surface p-6">
              <div className="flex items-center gap-3">
                <PlayCircle className="size-6 text-plum" aria-hidden="true" />
                <h2 id="videos-title" className="font-display text-xl font-semibold">Training videos</h2>
                <span className="text-sm text-ink-faint">{countVideos(trainingHub)} videos</span>
              </div>
              <ul className="mt-4 grid gap-x-6 sm:grid-cols-2">
                {videoSections.map((v) => (
                  <li key={v.href}>
                    <Link href={v.href} className="group flex items-baseline gap-2 py-2">
                      <span className="font-medium group-hover:text-plum">{displayTitle(v.label)}</span>
                      <span className="leader" aria-hidden="true" />
                      <span className="text-sm text-ink-faint">{countVideos(getPageByUrl(v.href))}</span>
                    </Link>
                  </li>
                ))}
              </ul>
            </section>
          )}
          <section aria-labelledby="faq-title" className="rounded-2xl border border-line bg-surface p-6">
            <div className="flex items-center gap-3">
              <CircleHelp className="size-6 text-plum" aria-hidden="true" />
              <h2 id="faq-title" className="font-display text-xl font-semibold">Quick answers</h2>
            </div>
            <ul className="mt-4 space-y-2.5">
              {faqs.slice(0, 4).map((f) => (
                <li key={f.id}><Link href={`/faq/#${f.slug}`} className="hover:text-plum hover:underline">{f.question}</Link></li>
              ))}
            </ul>
            <Link href="/faq/" className="mt-5 inline-flex items-center gap-1 text-sm font-medium text-plum hover:underline">
              All {faqs.length} FAQs <ChevronRight className="size-4" aria-hidden="true" />
            </Link>
          </section>
        </div>
      </div>
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: jsonLd(websiteJsonLd()) }} />
    </>
  );
}
