import { buildSearchDocuments } from "@/lib/search-index";

// Emitted as a static file at build time (/search-index.json).
export const dynamic = "force-static";

export function GET() {
  return Response.json(buildSearchDocuments());
}
