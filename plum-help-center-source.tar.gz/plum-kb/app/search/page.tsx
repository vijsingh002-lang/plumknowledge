import { Suspense } from "react";
import { buildMetadata } from "@/lib/seo";
import { SkeletonRows } from "@/components/ui/States";
import { SearchPageClient } from "@/components/search/SearchPageClient";

export const metadata = buildMetadata({ title: "Search", description: "Search the Plum Central Help Center.", path: "/search/", noindex: true });

export default function SearchPage() {
  return (
    <div className="mx-auto max-w-3xl px-4 pt-10 sm:px-6">
      <h1 className="font-display text-[2rem] font-bold tracking-tight sm:text-[2.5rem]">Search</h1>
      <div className="mt-6">
        <Suspense fallback={<SkeletonRows rows={5} />}>
          <SearchPageClient />
        </Suspense>
      </div>
    </div>
  );
}
