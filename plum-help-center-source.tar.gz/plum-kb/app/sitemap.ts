import type { MetadataRoute } from "next";
import { getArticles, getCategories, getPages, getTags } from "@/lib/content";
import { absoluteUrl } from "@/lib/seo";

export const dynamic = "force-static";

export default function sitemap(): MetadataRoute.Sitemap {
  const newest = getArticles().reduce((m, a) => (a.updatedAt > m ? a.updatedAt : m), "1970-01-01");
  return [
    { url: absoluteUrl("/"), lastModified: newest, priority: 1 },
    ...getArticles().map((a) => ({ url: absoluteUrl(a.url), lastModified: a.updatedAt, priority: 0.8 })),
    ...getPages().map((p) => ({ url: absoluteUrl(p.url), lastModified: p.updatedAt, priority: 0.6 })),
    ...getCategories().filter((c) => c.articleCount > 0).map((c) => ({ url: absoluteUrl(c.url), priority: 0.5 })),
    ...getTags().map((t) => ({ url: absoluteUrl(t.url), priority: 0.3 })),
  ];
}
