import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { getArticlesWithTag, getTagBySlug, getTags } from "@/lib/content";
import { buildMetadata } from "@/lib/seo";
import { pluralize } from "@/lib/format";
import { Breadcrumbs } from "@/components/ui/Breadcrumbs";
import { ArticleList, toListItem } from "@/components/article/ArticleList";

export const dynamicParams = false;
export const generateStaticParams = () => getTags().map((t) => ({ slug: t.slug }));

type Props = { params: Promise<{ slug: string }> };

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const tag = getTagBySlug((await params).slug);
  return tag ? buildMetadata({ title: `Articles tagged “${tag.name}”`, description: `${pluralize(tag.articleCount, "article")} tagged ${tag.name}.`, path: tag.url }) : {};
}

export default async function TagPage({ params }: Props) {
  const tag = getTagBySlug((await params).slug);
  if (!tag) notFound();
  return (
    <div className="mx-auto max-w-4xl px-4 pt-6 sm:px-6 lg:pt-10">
      <Breadcrumbs items={[{ name: tag.name, url: tag.url }]} />
      <h1 className="mt-6 font-display text-[2rem] font-bold tracking-tight sm:text-[2.5rem]">{tag.name}</h1>
      <p className="mt-2 text-ink-soft">{pluralize(tag.articleCount, "article")} with this tag</p>
      <div className="mt-8"><ArticleList items={getArticlesWithTag(tag).map(toListItem)} showExcerpt /></div>
    </div>
  );
}
