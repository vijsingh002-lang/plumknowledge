"use client";

import { useState } from "react";
import { Check, Link2, Printer } from "lucide-react";

export function ArticleActions() {
  const [copied, setCopied] = useState(false);

  const copy = async () => {
    try {
      await navigator.clipboard.writeText(window.location.href.split("#")[0]);
      setCopied(true);
      window.setTimeout(() => setCopied(false), 2000);
    } catch {
      window.prompt("Copy this link:", window.location.href);
    }
  };

  const btn = "inline-flex items-center gap-1.5 rounded-lg border border-line bg-surface px-2.5 py-1.5 text-sm text-ink-soft hover:border-line-strong hover:text-ink";
  return (
    <div className="no-print flex gap-2">
      <button type="button" onClick={copy} className={btn} aria-live="polite">
        {copied ? <Check className="size-4 text-leaf" aria-hidden="true" /> : <Link2 className="size-4" aria-hidden="true" />}
        {copied ? "Link copied" : "Copy link"}
      </button>
      <button type="button" onClick={() => window.print()} className={btn}>
        <Printer className="size-4" aria-hidden="true" />
        Print
      </button>
    </div>
  );
}
