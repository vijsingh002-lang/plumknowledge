/**
 * Renders article HTML. The HTML is not raw WordPress output: the exporter
 * (scripts/wp/html.ts) has already passed it through a strict sanitize-html
 * allowlist at build time — no scripts, event handlers, styles, or
 * unapproved iframe/video hosts can survive. Nothing user-submitted is
 * ever rendered here.
 */
export function ArticleBody({ html }: { html: string }) {
  return <div className="prose-kb" dangerouslySetInnerHTML={{ __html: html }} />;
}
