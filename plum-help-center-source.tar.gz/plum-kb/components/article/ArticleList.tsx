import Link from "next/link";
import { ChevronRight } from "lucide-react";
import type { Article } from "@/types/content";
import { getCategoryTrail } from "@/lib/content";
import { displayTitle } from "@/lib/site-config";
import { formatMonth } from "@/lib/format";

export type ArticleListItem = { url: string; title: string; crumb: string; updatedAt: string; excerpt?: string };

export function toListItem(a: Article): ArticleListItem {
  return {
    url: a.url,
    title: a.title,
    crumb: getCategoryTrail(a.primaryCategoryId).map((c) => displayTitle(c.name)).join(" / "),
    updatedAt: a.updatedAt,
    excerpt: a.excerpt,
  };
}

/** Divided list of articles; used by category, tag, listing and search pages. */
export function ArticleList({ items, showExcerpt = false }: { items: ArticleListItem[]; showExcerpt?: boolean }) {
  return (
    <ul className="divide-y divide-line overflow-hidden rounded-2xl border border-line bg-surface">
      {items.map((a) => (
        <li key={a.url}>
          <Link href={a.url} className="group flex items-center gap-4 px-5 py-4 transition-colors hover:bg-plum-wash/50">
            <span className="min-w-0 flex-1">
              <span className="block font-medium text-ink group-hover:text-plum">{a.title}</span>
              {showExcerpt && a.excerpt && <span className="mt-1 line-clamp-2 block text-sm text-ink-soft">{a.excerpt}</span>}
              <span className="mt-1 flex flex-wrap gap-x-3 text-xs text-ink-faint">
                {a.crumb && <span>{a.crumb}</span>}
                <span>Updated {formatMonth(a.updatedAt)}</span>
              </span>
            </span>
            <ChevronRight className="size-4 shrink-0 text-ink-faint transition-transform group-hover:translate-x-0.5 group-hover:text-plum" aria-hidden="true" />
          </Link>
        </li>
      ))}
    </ul>
  );
}
