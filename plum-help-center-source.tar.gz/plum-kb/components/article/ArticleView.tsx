import Link from "next/link";
import type { Article } from "@/types/content";
import { getArticlesInCategory, getCategoryById, getCategoryTrail, getTagsForArticle } from "@/lib/content";
import { getAdjacentArticles, getRelatedArticles } from "@/lib/ranking";
import { GENERIC_AUTHORS, displayTitle } from "@/lib/site-config";
import { articleJsonLd, jsonLd } from "@/lib/seo";
import { formatDate } from "@/lib/format";
import { Breadcrumbs } from "@/components/ui/Breadcrumbs";
import { ArticleBody } from "./ArticleBody";
import { ArticleActions } from "./ArticleActions";
import { Feedback } from "./Feedback";
import { MobileToc } from "./MobileToc";
import { PrevNext, RelatedArticles } from "./RelatedAndAdjacent";
import { TableOfContents } from "./TableOfContents";
import { TrackView } from "./TrackView";

export function ArticleView({ article }: { article: Article }) {
  const trail = getCategoryTrail(article.primaryCategoryId);
  const category = getCategoryById(article.primaryCategoryId);
  const siblings = category ? getArticlesInCategory(category.id) : [];
  const related = getRelatedArticles(article);
  const { prev, next } = getAdjacentArticles(article);
  const tags = getTagsForArticle(article);
  const author = article.author && !GENERIC_AUTHORS.has(article.author.toLowerCase()) ? article.author : null;

  return (
    <div className="mx-auto max-w-7xl px-4 pt-6 sm:px-6 lg:pt-10">
      <Breadcrumbs items={[...trail.map((c) => ({ name: displayTitle(c.name), url: c.url })), { name: article.title, url: article.url }]} />

      <div className="mt-6 grid gap-10 lg:grid-cols-[minmax(0,1fr)_14rem] xl:grid-cols-[15rem_minmax(0,1fr)_14rem]">
        {/* Category navigation (wide screens) */}
        {category && siblings.length > 1 && (
          <aside className="no-print hidden xl:block">
            <nav aria-label={`Articles in ${displayTitle(category.name)}`} className="sticky top-24 max-h-[calc(100dvh-7rem)] overflow-y-auto pr-2">
              <Link href={category.url} className="font-display font-semibold hover:text-plum">{displayTitle(category.name)}</Link>
              <ul className="mt-3 space-y-0.5 text-sm">
                {siblings.map((s) => (
                  <li key={s.id}>
                    <Link
                      href={s.url}
                      aria-current={s.id === article.id ? "page" : undefined}
                      className="block rounded-md px-2.5 py-1.5 leading-snug text-ink-soft hover:bg-plum-wash hover:text-ink aria-[current=page]:bg-plum-wash aria-[current=page]:font-medium aria-[current=page]:text-plum"
                    >
                      {s.title}
                    </Link>
                  </li>
                ))}
              </ul>
            </nav>
          </aside>
        )}
        {!(category && siblings.length > 1) && <div className="hidden xl:block" />}

        <article className="min-w-0">
          <header className="border-b border-line pb-6">
            <h1 className="font-display text-[2rem] font-bold leading-[1.15] tracking-tight text-balance sm:text-[2.5rem]">{article.title}</h1>
            <div className="mt-4 flex flex-wrap items-center justify-between gap-3">
              <p className="flex flex-wrap gap-x-4 gap-y-1 text-sm text-ink-soft">
                <span>Updated <time dateTime={article.updatedAt}>{formatDate(article.updatedAt)}</time></span>
                <span>{article.readingMinutes} min read</span>
                {author && <span>By {author}</span>}
              </p>
              <ArticleActions />
            </div>
          </header>

          <div className="mt-6"><MobileToc items={article.toc} /></div>
          <div className="mt-8"><ArticleBody html={article.html} /></div>

          {tags.length > 0 && (
            <ul className="no-print mt-10 flex flex-wrap gap-2" aria-label="Tags">
              {tags.map((t) => (
                <li key={t.id}>
                  <Link href={t.url} className="rounded-full border border-line px-3 py-1 text-sm text-ink-soft hover:border-plum hover:text-plum">{t.name}</Link>
                </li>
              ))}
            </ul>
          )}

          <div className="mt-12 space-y-12">
            <Feedback url={article.url} />
            <PrevNext prev={prev} next={next} />
            <RelatedArticles from={article} articles={related} />
          </div>
        </article>

        {article.toc.length >= 2 ? (
          <aside className="no-print hidden lg:block">
            <div className="sticky top-24 max-h-[calc(100dvh-7rem)] overflow-y-auto"><TableOfContents items={article.toc} /></div>
          </aside>
        ) : <div className="hidden lg:block" />}
      </div>

      <TrackView event={{ name: "article_opened", url: article.url, title: article.title }} />
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: jsonLd(articleJsonLd(article, category)) }} />
    </div>
  );
}
