"use client";

import { useStoredValue } from "@/hooks/useStoredValue";
import Link from "next/link";
import { ThumbsDown, ThumbsUp } from "lucide-react";
import { track } from "@/lib/analytics";

const KEY = "kb-feedback";

/**
 * "Was this helpful?" There is no backend: the vote is sent as an analytics
 * event (feedback_submitted) and remembered locally so readers vote once.
 */
function parseVotes(raw: string | null): Record<string, boolean> {
  try {
    const v = JSON.parse(raw || "{}");
    return v && typeof v === "object" ? v : {};
  } catch {
    return {};
  }
}

export function Feedback({ url }: { url: string }) {
  const [raw, store] = useStoredValue(KEY);
  const votes = parseVotes(raw);
  const vote = typeof votes[url] === "boolean" ? votes[url] : null;

  const submit = (helpful: boolean) => {
    track({ name: "feedback_submitted", url, helpful });
    store(JSON.stringify({ ...votes, [url]: helpful }));
  };

  const btn = "inline-flex items-center gap-2 rounded-lg border border-line-strong bg-surface px-4 py-2 font-medium transition-colors";
  return (
    <section aria-labelledby="feedback-title" className="no-print rounded-2xl border border-line bg-surface px-5 py-5 sm:flex sm:items-center sm:justify-between sm:gap-6">
      {vote === null ? (
        <>
          <h2 id="feedback-title" className="font-display text-lg font-semibold">Was this article helpful?</h2>
          <div className="mt-3 flex gap-2 sm:mt-0">
            <button type="button" onClick={() => submit(true)} className={`${btn} hover:border-leaf hover:text-leaf`}>
              <ThumbsUp className="size-4" aria-hidden="true" /> Yes
            </button>
            <button type="button" onClick={() => submit(false)} className={`${btn} hover:border-plum hover:text-plum`}>
              <ThumbsDown className="size-4" aria-hidden="true" /> No
            </button>
          </div>
        </>
      ) : (
        <div role="status">
          <h2 id="feedback-title" className="font-display text-lg font-semibold">{vote ? "Thanks for letting us know." : "Thanks. We'll use this to improve the article."}</h2>
          {!vote && (
            <p className="mt-1 text-ink-soft">
              Still stuck? Check the <Link href="/faq/" className="text-plum underline underline-offset-2">FAQs</Link> or the{" "}
              <Link href="/training-videos/" className="text-plum underline underline-offset-2">training videos</Link>.
            </p>
          )}
        </div>
      )}
    </section>
  );
}
