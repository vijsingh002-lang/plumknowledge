import { ChevronDown } from "lucide-react";
import type { TocEntry } from "@/types/content";

/** Collapsible table of contents for narrow screens (native <details>, no JS). */
export function MobileToc({ items }: { items: TocEntry[] }) {
  if (items.length < 2) return null;
  return (
    <details className="group no-print rounded-xl border border-line bg-surface lg:hidden">
      <summary className="flex cursor-pointer list-none items-center justify-between px-4 py-3 font-medium [&::-webkit-details-marker]:hidden">
        On this page
        <ChevronDown className="size-4 text-ink-soft transition-transform group-open:rotate-180" aria-hidden="true" />
      </summary>
      <ul className="space-y-1 border-t border-line px-4 py-3 text-sm">
        {items.map((i) => (
          <li key={i.id} className={i.level === 3 ? "pl-4" : ""}>
            <a href={`#${i.id}`} className="block py-1 text-ink-soft hover:text-plum">{i.text}</a>
          </li>
        ))}
      </ul>
    </details>
  );
}
