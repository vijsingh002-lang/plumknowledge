import { ChevronLeft, ChevronRight } from "lucide-react";
import type { Article } from "@/types/content";
import { TrackedLink } from "./TrackedLink";

export function RelatedArticles({ from, articles }: { from: Article; articles: Article[] }) {
  if (!articles.length) return null;
  return (
    <section aria-labelledby="related-title" className="no-print">
      <h2 id="related-title" className="font-display text-xl font-semibold">Related articles</h2>
      <ul className="mt-4 grid gap-3 sm:grid-cols-2">
        {articles.map((a) => (
          <li key={a.id}>
            <TrackedLink
              href={a.url}
              event={{ name: "related_article_clicked", from: from.url, to: a.url }}
              className="block h-full rounded-xl border border-line bg-surface px-4 py-3.5 transition-colors hover:border-plum"
            >
              <span className="block font-medium leading-snug">{a.title}</span>
              <span className="mt-1 line-clamp-2 block text-sm text-ink-soft">{a.excerpt}</span>
            </TrackedLink>
          </li>
        ))}
      </ul>
    </section>
  );
}

export function PrevNext({ prev, next }: { prev?: Article; next?: Article }) {
  if (!prev && !next) return null;
  const card = "group flex h-full flex-col rounded-xl border border-line px-4 py-3.5 transition-colors hover:border-plum";
  return (
    <nav aria-label="More in this category" className="no-print grid gap-3 sm:grid-cols-2">
      {prev ? (
        <TrackedLink href={prev.url} event={{ name: "related_article_clicked", from: "prev", to: prev.url }} className={card}>
          <span className="flex items-center gap-1 text-sm text-ink-faint"><ChevronLeft className="size-4" aria-hidden="true" />Previous</span>
          <span className="mt-1 font-medium group-hover:text-plum">{prev.title}</span>
        </TrackedLink>
      ) : <span />}
      {next && (
        <TrackedLink href={next.url} event={{ name: "related_article_clicked", from: "next", to: next.url }} className={`${card} sm:items-end sm:text-right`}>
          <span className="flex items-center gap-1 text-sm text-ink-faint">Next<ChevronRight className="size-4" aria-hidden="true" /></span>
          <span className="mt-1 font-medium group-hover:text-plum">{next.title}</span>
        </TrackedLink>
      )}
    </nav>
  );
}
