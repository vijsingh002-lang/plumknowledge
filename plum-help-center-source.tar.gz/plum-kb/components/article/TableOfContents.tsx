"use client";

import { useEffect, useState } from "react";
import type { TocEntry } from "@/types/content";

/** Sticky "On this page" list that tracks the heading currently in view. */
export function TableOfContents({ items }: { items: TocEntry[] }) {
  const [active, setActive] = useState(items[0]?.id);

  useEffect(() => {
    const headings = items.map((i) => document.getElementById(i.id)).filter((h): h is HTMLElement => !!h);
    if (!headings.length) return;
    const observer = new IntersectionObserver(
      (entries) => {
        const visible = entries.filter((e) => e.isIntersecting).sort((a, b) => a.boundingClientRect.top - b.boundingClientRect.top);
        if (visible[0]) setActive(visible[0].target.id);
      },
      { rootMargin: "-88px 0px -65% 0px" },
    );
    headings.forEach((h) => observer.observe(h));
    return () => observer.disconnect();
  }, [items]);

  return (
    <nav aria-label="On this page">
      <p className="text-sm font-semibold text-ink">On this page</p>
      <ul className="mt-3 space-y-0.5 border-l border-line text-sm">
        {items.map((i) => (
          <li key={i.id}>
            <a
              href={`#${i.id}`}
              aria-current={active === i.id ? "location" : undefined}
              className={`-ml-px block border-l-2 py-1 leading-snug transition-colors ${i.level === 3 ? "pl-6" : "pl-3"} ${
                active === i.id ? "border-plum font-medium text-plum" : "border-transparent text-ink-soft hover:text-ink"
              }`}
            >
              {i.text}
            </a>
          </li>
        ))}
      </ul>
    </nav>
  );
}
