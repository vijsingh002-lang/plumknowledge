"use client";

import { useMemo, useState } from "react";
import { Search } from "lucide-react";
import { ArticleList, type ArticleListItem } from "@/components/article/ArticleList";
import { EmptyState } from "@/components/ui/States";

/** Article list with an instant "search within this category" filter. */
export function CategoryArticles({ items, categoryName }: { items: ArticleListItem[]; categoryName: string }) {
  const [q, setQ] = useState("");
  const filtered = useMemo(() => {
    const words = q.toLowerCase().split(/\s+/).filter(Boolean);
    if (!words.length) return items;
    return items.filter((a) => {
      const hay = `${a.title} ${a.crumb} ${a.excerpt ?? ""}`.toLowerCase();
      return words.every((w) => hay.includes(w));
    });
  }, [q, items]);

  return (
    <div>
      {items.length > 5 && (
        <div className="relative mb-4 max-w-md">
          <Search className="pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-ink-faint" aria-hidden="true" />
          <input
            type="search"
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder={`Filter ${items.length} articles`}
            aria-label={`Filter articles in ${categoryName}`}
            maxLength={100}
            className="h-10 w-full rounded-lg border border-line bg-surface pl-9 pr-3 text-[0.95rem] outline-none placeholder:text-ink-faint focus:border-plum"
          />
        </div>
      )}
      <p className="sr-only" aria-live="polite">{filtered.length} articles shown</p>
      {filtered.length ? (
        <ArticleList items={filtered} showExcerpt />
      ) : (
        <EmptyState title="No articles match that filter.">Clear the filter or search the whole help center with Ctrl + K.</EmptyState>
      )}
    </div>
  );
}
