import Link from "next/link";
import type { Article } from "@/types/content";
import { RelativeDate } from "@/components/ui/RelativeDate";

export function ArticleColumn({ title, note, articles, dated = false }: { title: string; note?: string; articles: Article[]; dated?: boolean }) {
  const id = title.toLowerCase().replace(/\s+/g, "-");
  return (
    <section aria-labelledby={id}>
      <h2 id={id} className="font-display text-xl font-semibold">{title}</h2>
      {note && <p className="mt-1 text-sm text-ink-faint">{note}</p>}
      <ul className="mt-4 divide-y divide-line border-y border-line">
        {articles.map((a) => (
          <li key={a.id}>
            <Link href={a.url} className="group flex items-baseline justify-between gap-4 py-3">
              <span className="font-medium group-hover:text-plum">{a.title}</span>
              {dated && <span className="shrink-0 text-sm text-ink-faint"><RelativeDate iso={a.updatedAt} /></span>}
            </Link>
          </li>
        ))}
      </ul>
    </section>
  );
}
