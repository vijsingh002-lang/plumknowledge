import Link from "next/link";
import type { Article, Category } from "@/types/content";
import { displayTitle, presentationFor } from "@/lib/site-config";
import { CategoryIcon } from "@/components/ui/CategoryIcon";

type Entry = { category: Category; top: Article[] };

/**
 * Product directory. Each panel reads like a menu board: name, dotted
 * leader, count, then the first few dishes (articles) in that section.
 */
export function CategoryDirectory({ entries }: { entries: Entry[] }) {
  return (
    <ul className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
      {entries.map(({ category: c, top }) => (
        <li key={c.id} className="group relative flex flex-col rounded-2xl border border-line bg-surface p-5 transition-[border-color,transform] duration-200 hover:-translate-y-0.5 hover:border-plum">
          <div className="flex items-center gap-3">
            <span className="flex size-10 shrink-0 items-center justify-center rounded-xl bg-plum-wash text-plum transition-colors group-hover:bg-plum group-hover:text-paper">
              <CategoryIcon slug={c.slug} />
            </span>
            <h3 className="flex min-w-0 flex-1 items-baseline gap-2">
              {/* The heading link covers the whole card; article links sit above it. */}
              <Link href={c.url} className="font-display text-lg font-semibold after:absolute after:inset-0 after:rounded-2xl focus-visible:outline-none focus-visible:after:outline-2 focus-visible:after:outline-plum">
                {displayTitle(c.name)}
              </Link>
              <span className="leader" aria-hidden="true" />
              <span className="shrink-0 text-sm text-ink-faint">{c.articleCount}<span className="sr-only"> articles</span></span>
            </h3>
          </div>
          <p className="mt-3 text-[0.95rem] leading-relaxed text-ink-soft">{presentationFor(c.slug).description}</p>
          {top.length > 0 && (
            <ul className="relative mt-4 space-y-1.5 border-t border-line pt-3 text-sm">
              {top.map((a) => (
                <li key={a.id}>
                  <Link href={a.url} className="line-clamp-1 text-ink hover:text-plum hover:underline">{a.title}</Link>
                </li>
              ))}
            </ul>
          )}
        </li>
      ))}
    </ul>
  );
}
