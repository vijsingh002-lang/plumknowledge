import { Search } from "lucide-react";
import { SUGGESTED_SEARCHES } from "@/lib/site-config";

/** Works without JavaScript: a plain GET form to /search/. */
export function HeroSearch() {
  return (
    <div>
      <form action="/search/" method="get" role="search" className="relative">
        <label htmlFor="hero-q" className="sr-only">Search the help center</label>
        <Search className="pointer-events-none absolute left-4 top-1/2 size-5 -translate-y-1/2 text-plum" aria-hidden="true" />
        <input
          id="hero-q"
          name="q"
          type="search"
          required
          maxLength={100}
          placeholder="Search guides and videos"
          className="h-14 w-full rounded-2xl border border-line-strong bg-surface pl-12 pr-28 text-[1.05rem] shadow-[0_1px_0_var(--line)] outline-none placeholder:text-ink-faint focus:border-plum"
        />
        <button type="submit" className="absolute right-2 top-1/2 h-10 -translate-y-1/2 rounded-xl bg-plum px-4 font-medium text-paper hover:bg-plum-strong">
          Search
        </button>
      </form>
      <p className="mt-4 flex flex-wrap items-center gap-x-2 gap-y-2 text-sm text-ink-soft">
        <span>Popular topics:</span>
        {SUGGESTED_SEARCHES.map((s) => (
          <a key={s} href={`/search/?q=${encodeURIComponent(s)}`} className="rounded-full border border-line bg-surface px-2.5 py-0.5 hover:border-plum hover:text-plum">{s}</a>
        ))}
      </p>
    </div>
  );
}
