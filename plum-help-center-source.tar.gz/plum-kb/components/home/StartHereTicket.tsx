import Link from "next/link";
import type { Article } from "@/types/content";

/**
 * The homepage's signature element: the new-store setup path printed like a
 * kitchen order ticket. The steps are a real sequence, so they are numbered.
 */
export function StartHereTicket({ steps, categoryUrl }: { steps: Article[]; categoryUrl: string }) {
  const minutes = steps.reduce((n, s) => n + s.readingMinutes, 0);
  return (
    <section aria-labelledby="start-title" className="ticket relative px-6 pb-8 pt-9 shadow-[0_18px_40px_-24px_rgb(30_16_38/0.35)] ring-1 ring-line">
      <div className="flex items-baseline justify-between border-b-2 border-dashed border-line-strong pb-3">
        <h2 id="start-title" className="font-display text-xl font-bold">Setting up a new store?</h2>
        <span className="text-sm text-ink-faint">{minutes} min</span>
      </div>
      <ol className="mt-4 space-y-1">
        {steps.map((s, i) => (
          <li key={s.id}>
            <Link href={s.url} className="group flex items-start gap-3 rounded-lg py-2 hover:text-plum">
              <span className="flex size-7 shrink-0 items-center justify-center rounded-full border-2 border-plum font-display text-sm font-bold text-plum group-hover:bg-plum group-hover:text-paper">
                {i + 1}
              </span>
              <span className="flex min-w-0 flex-1 items-baseline gap-2 pt-0.5">
                <span className="font-medium leading-snug">{s.title.replace(/\s*\?$/, "")}</span>
                <span className="leader" aria-hidden="true" />
                <span className="shrink-0 text-sm text-ink-faint">{s.readingMinutes}m</span>
              </span>
            </Link>
          </li>
        ))}
      </ol>
      <Link href={categoryUrl} className="mt-4 inline-block text-sm font-medium text-plum hover:underline">
        All getting-started articles
      </Link>
    </section>
  );
}
