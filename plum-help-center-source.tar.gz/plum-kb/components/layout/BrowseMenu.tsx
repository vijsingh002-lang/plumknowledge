"use client";

import { useEffect, useRef, useState } from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { useChanged } from "@/hooks/useChanged";
import { ChevronDown } from "lucide-react";
import type { NavCategory } from "./SiteHeader";
import { CategoryIconClient } from "./CategoryIconClient";

/** Desktop "Browse" disclosure listing every product category. */
export function BrowseMenu({ categories }: { categories: NavCategory[] }) {
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);
  const pathname = usePathname();

  if (useChanged(pathname) && open) setOpen(false);
  useEffect(() => {
    if (!open) return;
    const onDown = (e: MouseEvent) => !ref.current?.contains(e.target as Node) && setOpen(false);
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && setOpen(false);
    document.addEventListener("mousedown", onDown);
    document.addEventListener("keydown", onKey);
    return () => {
      document.removeEventListener("mousedown", onDown);
      document.removeEventListener("keydown", onKey);
    };
  }, [open]);

  return (
    <div ref={ref} className="relative">
      <button
        type="button"
        onClick={() => setOpen((o) => !o)}
        aria-expanded={open}
        aria-controls="browse-menu"
        className="flex items-center gap-1 rounded-lg px-3 py-2 text-[0.95rem] text-ink-soft hover:bg-plum-wash hover:text-ink aria-expanded:text-ink"
      >
        Browse
        <ChevronDown className={`size-4 transition-transform ${open ? "rotate-180" : ""}`} aria-hidden="true" />
      </button>
      {open && (
        <div id="browse-menu" className="absolute left-0 top-full z-50 mt-2 w-[34rem] rounded-2xl border border-line bg-surface p-2 shadow-[0_18px_40px_-18px_rgb(30_16_38/0.35)]">
          <ul className="grid grid-cols-2 gap-1">
            {categories.map((c) => (
              <li key={c.url}>
                <Link href={c.url} className="flex items-start gap-3 rounded-xl px-3 py-2.5 hover:bg-plum-wash">
                  <span className="mt-0.5 text-plum"><CategoryIconClient icon={c.icon} /></span>
                  <span>
                    <span className="block font-medium text-ink">{c.name}</span>
                    <span className="text-sm text-ink-faint">{c.count} article{c.count === 1 ? "" : "s"}</span>
                  </span>
                </Link>
              </li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
}
