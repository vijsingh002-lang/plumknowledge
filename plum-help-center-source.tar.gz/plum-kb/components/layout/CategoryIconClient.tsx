import { CalendarDays, ChartColumn, Clock, CreditCard, Folder, MonitorSmartphone, Music, Percent, Rocket, SlidersHorizontal, Wrench } from "lucide-react";
import type { CategoryIconName } from "@/lib/site-config";

const ICONS = { monitor: MonitorSmartphone, sliders: SlidersHorizontal, chart: ChartColumn, calendar: CalendarDays, music: Music, clock: Clock, card: CreditCard, percent: Percent, wrench: Wrench, rocket: Rocket, folder: Folder };

/** Icon by name, usable from client components (props must be serializable). */
export function CategoryIconClient({ icon, className = "size-5" }: { icon: CategoryIconName; className?: string }) {
  const Icon = ICONS[icon];
  return <Icon className={className} strokeWidth={1.75} aria-hidden="true" />;
}
