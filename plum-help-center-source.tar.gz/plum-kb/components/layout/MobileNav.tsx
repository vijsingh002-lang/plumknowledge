"use client";

import { useEffect, useRef, useState } from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { useChanged } from "@/hooks/useChanged";
import { Menu, X } from "lucide-react";
import type { NavCategory } from "./SiteHeader";
import { CategoryIconClient } from "./CategoryIconClient";
import { Logo } from "@/components/ui/Logo";

type Props = { links: { label: string; href: string }[]; categories: NavCategory[] };

/** Full-height mobile menu in a native modal <dialog>. */
export function MobileNav({ links, categories }: Props) {
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDialogElement>(null);
  const pathname = usePathname();

  if (useChanged(pathname) && open) setOpen(false);
  useEffect(() => {
    const d = ref.current;
    if (!d) return;
    if (open && !d.open) d.showModal();
    if (!open && d.open) d.close();
  }, [open]);

  return (
    <>
      <button type="button" onClick={() => setOpen(true)} className="-ml-2 rounded-lg p-2 text-ink hover:bg-plum-wash lg:hidden" aria-label="Open menu" aria-haspopup="dialog">
        <Menu className="size-6" aria-hidden="true" />
      </button>
      <dialog ref={ref} onClose={() => setOpen(false)} aria-label="Menu" className="m-0 h-dvh max-h-none w-full max-w-sm bg-surface p-0 text-ink backdrop:bg-ink/35">
        <div className="flex h-16 items-center justify-between border-b border-line px-4">
          <Logo />
          <button type="button" onClick={() => setOpen(false)} className="rounded-lg p-2 hover:bg-plum-wash" aria-label="Close menu">
            <X className="size-6" aria-hidden="true" />
          </button>
        </div>
        <nav aria-label="Mobile" className="overflow-y-auto px-3 py-4">
          <ul className="space-y-0.5">
            {links.map((l) => (
              <li key={l.href}>
                <Link href={l.href} aria-current={pathname === l.href ? "page" : undefined} className="block rounded-lg px-3 py-2.5 text-[1.05rem] font-medium hover:bg-plum-wash aria-[current=page]:text-plum">
                  {l.label}
                </Link>
              </li>
            ))}
          </ul>
          <p className="mt-6 px-3 text-sm font-medium text-ink-faint">Browse by product</p>
          <ul className="mt-2 space-y-0.5">
            {categories.map((c) => (
              <li key={c.url}>
                <Link href={c.url} className="flex items-center gap-3 rounded-lg px-3 py-2.5 hover:bg-plum-wash">
                  <span className="text-plum"><CategoryIconClient icon={c.icon} /></span>
                  <span className="flex-1">{c.name}</span>
                  <span className="text-sm text-ink-faint">{c.count}</span>
                </Link>
              </li>
            ))}
          </ul>
        </nav>
      </dialog>
    </>
  );
}
