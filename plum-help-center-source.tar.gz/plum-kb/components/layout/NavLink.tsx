"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";

export function NavLink({ href, children }: { href: string; children: React.ReactNode }) {
  const pathname = usePathname();
  const current = pathname === href || (href !== "/" && pathname.startsWith(href));
  return (
    <Link href={href} aria-current={current ? "page" : undefined} className="rounded-lg px-3 py-2 text-[0.95rem] text-ink-soft hover:bg-plum-wash hover:text-ink aria-[current=page]:font-medium aria-[current=page]:text-plum">
      {children}
    </Link>
  );
}
