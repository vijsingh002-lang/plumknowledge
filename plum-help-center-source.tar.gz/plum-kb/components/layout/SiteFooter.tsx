import Link from "next/link";
import { BRAND } from "@/lib/site-config";
import { PlumGlyph } from "@/components/ui/Logo";
import { getNavData } from "./SiteHeader";

export function SiteFooter() {
  const { links, categories } = getNavData();
  return (
    <footer className="no-print mt-24 border-t border-line">
      <div className="mx-auto grid max-w-7xl gap-10 px-4 py-12 sm:px-6 md:grid-cols-[1.4fr_1fr_1fr]">
        <div>
          <div className="flex items-center gap-2.5">
            <PlumGlyph />
            <span className="font-display text-lg font-bold">{BRAND.title}</span>
          </div>
          <p className="mt-3 max-w-sm text-sm leading-relaxed text-ink-soft">{BRAND.description}</p>
        </div>
        <nav aria-label="Products">
          <p className="text-sm font-semibold">Products</p>
          <ul className="mt-3 space-y-2 text-sm text-ink-soft">
            {categories.map((c) => (
              <li key={c.url}><Link href={c.url} className="hover:text-plum">{c.name}</Link></li>
            ))}
          </ul>
        </nav>
        <nav aria-label="Resources">
          <p className="text-sm font-semibold">Resources</p>
          <ul className="mt-3 space-y-2 text-sm text-ink-soft">
            {links.map((l) => (
              <li key={l.href}><Link href={l.href} className="hover:text-plum">{l.label}</Link></li>
            ))}
            <li><Link href="/search/" className="hover:text-plum">Search</Link></li>
          </ul>
        </nav>
      </div>
      <div className="border-t border-line">
        <p className="mx-auto max-w-7xl px-4 py-5 text-sm text-ink-faint sm:px-6">© {new Date().getFullYear()} {BRAND.company}. All rights reserved.</p>
      </div>
    </footer>
  );
}
