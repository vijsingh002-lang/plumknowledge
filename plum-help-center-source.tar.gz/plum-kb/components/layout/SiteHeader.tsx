import { getNavigation, getTopCategories } from "@/lib/content";
import { NAV_LABELS, displayTitle, presentationFor, type CategoryIconName } from "@/lib/site-config";
import { Logo } from "@/components/ui/Logo";
import { SearchTrigger } from "@/components/search/SearchTrigger";
import { BrowseMenu } from "./BrowseMenu";
import { MobileNav } from "./MobileNav";
import { NavLink } from "./NavLink";
import { ThemeToggle } from "./ThemeToggle";

export type NavCategory = { name: string; url: string; count: number; icon: CategoryIconName };

export function getNavData() {
  // Menu items come from the WordPress "Seo Main Menu"; "Home" is the logo.
  const links = getNavigation()
    .filter((n) => n.href !== "/")
    .map((n) => ({ label: NAV_LABELS[n.href] ?? displayTitle(n.label), href: n.href }));
  const categories: NavCategory[] = getTopCategories()
    .sort((a, b) => presentationFor(a.slug).order - presentationFor(b.slug).order)
    .map((c) => ({ name: displayTitle(c.name), url: c.url, count: c.articleCount, icon: presentationFor(c.slug).icon }));
  return { links, categories };
}

export function SiteHeader() {
  const { links, categories } = getNavData();
  return (
    <header className="no-print sticky top-0 z-40 border-b border-line bg-paper/85 backdrop-blur-md supports-[backdrop-filter]:bg-paper/75">
      <a href="#main" className="sr-only focus:not-sr-only focus:absolute focus:left-4 focus:top-3 focus:z-50 focus:rounded-lg focus:bg-surface focus:px-3 focus:py-2 focus:shadow">
        Skip to content
      </a>
      <div className="mx-auto flex h-16 max-w-7xl items-center gap-2 px-4 sm:px-6">
        <MobileNav links={links} categories={categories} />
        <Logo />
        <nav aria-label="Main" className="ml-6 hidden items-center gap-0.5 lg:flex">
          <BrowseMenu categories={categories} />
          {links.map((l) => (
            <NavLink key={l.href} href={l.href}>{l.label}</NavLink>
          ))}
        </nav>
        <div className="ml-auto flex items-center gap-1">
          <div className="hidden md:block"><SearchTrigger /></div>
          <div className="md:hidden"><SearchTrigger variant="icon" /></div>
          <ThemeToggle />
        </div>
      </div>
    </header>
  );
}
