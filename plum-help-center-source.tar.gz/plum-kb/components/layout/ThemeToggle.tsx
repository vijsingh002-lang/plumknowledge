"use client";

import { useEffect } from "react";
import { useStoredValue } from "@/hooks/useStoredValue";
import { Monitor, Moon, Sun } from "lucide-react";
import { applyTheme, THEME_KEY, type ThemePref } from "./theme";

const ORDER: ThemePref[] = ["light", "dark", "system"];
const META = {
  light: { icon: Sun, label: "Light theme" },
  dark: { icon: Moon, label: "Dark theme" },
  system: { icon: Monitor, label: "System theme" },
};

/** Cycles light → dark → system; the choice persists in localStorage. */
export function ThemeToggle() {
  const [stored, store] = useStoredValue(THEME_KEY);
  const pref: ThemePref = ORDER.includes(stored as ThemePref) ? (stored as ThemePref) : "system";

  useEffect(() => {
    if (pref !== "system") return;
    const mq = matchMedia("(prefers-color-scheme: dark)");
    const onChange = () => applyTheme("system");
    mq.addEventListener("change", onChange);
    return () => mq.removeEventListener("change", onChange);
  }, [pref]);

  const next = ORDER[(ORDER.indexOf(pref) + 1) % ORDER.length];
  const { icon: Icon, label } = META[pref];

  return (
    <button
      type="button"
      onClick={() => {
        applyTheme(next);
        store(next);
      }}
      className="rounded-lg p-2 text-ink-soft hover:bg-plum-wash hover:text-ink"
      aria-label={`${label}. Switch to ${META[next].label.toLowerCase()}`}
      title={label}
    >
      <Icon className="size-5" aria-hidden="true" />
    </button>
  );
}
