"use client";

import { useEffect } from "react";

/** Opens the question named in the URL hash (links from search and old /faq-items/ URLs). */
export function FaqHashOpener() {
  useEffect(() => {
    const open = () => {
      const el = window.location.hash && document.getElementById(decodeURIComponent(window.location.hash.slice(1)));
      if (el instanceof HTMLDetailsElement) {
        el.open = true;
        el.scrollIntoView({ block: "start" });
      }
    };
    open();
    window.addEventListener("hashchange", open);
    return () => window.removeEventListener("hashchange", open);
  }, []);
  return null;
}
