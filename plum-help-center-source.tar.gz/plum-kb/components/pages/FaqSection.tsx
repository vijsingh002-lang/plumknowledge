import { ChevronDown } from "lucide-react";
import type { Faq } from "@/types/content";
import { ArticleBody } from "@/components/article/ArticleBody";
import { FaqHashOpener } from "./FaqHashOpener";

/** Accordion of questions using native <details> (keyboard and screen-reader friendly with no JS). */
export function FaqSection({ title, faqs }: { title: string; faqs: Faq[] }) {
  if (!faqs.length) return null;
  const id = `group-${title.toLowerCase().replace(/[^a-z0-9]+/g, "-")}`;
  return (
    <section aria-labelledby={id} className="scroll-mt-24">
      <h2 id={id} className="font-display text-2xl font-semibold">{title}</h2>
      <div className="mt-4 divide-y divide-line rounded-2xl border border-line bg-surface">
        {faqs.map((f) => (
          <details key={f.id} id={f.slug} className="group scroll-mt-24">
            <summary className="flex cursor-pointer list-none items-start justify-between gap-4 px-5 py-4 font-medium hover:text-plum [&::-webkit-details-marker]:hidden">
              <span>{f.question}</span>
              <ChevronDown className="mt-1 size-4 shrink-0 text-ink-faint transition-transform group-open:rotate-180" aria-hidden="true" />
            </summary>
            <div className="px-5 pb-5 [&_.prose-kb]:text-base"><ArticleBody html={f.html} /></div>
          </details>
        ))}
      </div>
      <FaqHashOpener />
    </section>
  );
}
