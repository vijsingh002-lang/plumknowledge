import Link from "next/link";
import { ChevronRight, PlayCircle } from "lucide-react";
import type { PageBlock } from "@/types/content";
import { getPageByUrl } from "@/lib/content";
import { displayTitle } from "@/lib/site-config";

type LinksBlock = Extract<PageBlock, { kind: "links" }>;

/** Hub page tiles (Training videos → Plum POS, Plum Core, …). */
export function LinkGrid({ block }: { block: LinksBlock }) {
  return (
    <ul className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
      {block.items.map((item) => {
        const target = getPageByUrl(item.href);
        const videos = target?.blocks.reduce((n, b) => n + (b.kind === "videos" ? b.items.length : 0), 0) ?? 0;
        const children = target?.blocks.reduce((n, b) => n + (b.kind === "links" ? b.items.length : 0), 0) ?? 0;
        const meta = videos ? `${videos} video${videos === 1 ? "" : "s"}` : children ? `${children} sections` : target?.kind === "listing" ? "Articles" : "";
        return (
          <li key={item.href + item.label}>
            <Link href={item.href} className="group flex h-full flex-col overflow-hidden rounded-2xl border border-line bg-surface transition-colors hover:border-plum">
              {item.image ? (
                // eslint-disable-next-line @next/next/no-img-element -- static export; renditions pre-generated
                <img src={item.image.src} srcSet={item.image.srcSet} sizes="(min-width: 1024px) 380px, 100vw" width={item.image.width} height={item.image.height} alt="" loading="lazy" decoding="async" className="aspect-[16/9] w-full border-b border-line object-cover" />
              ) : (
                <span className="dot-field flex aspect-[16/9] items-center justify-center border-b border-line bg-plum-wash/60 text-plum" aria-hidden="true">
                  <PlayCircle className="size-9 opacity-70" strokeWidth={1.4} />
                </span>
              )}
              <span className="flex flex-1 items-center justify-between gap-3 px-4 py-3.5">
                <span>
                  <span className="block font-display font-semibold leading-snug group-hover:text-plum">{displayTitle(item.label)}</span>
                  {meta && <span className="text-sm text-ink-faint">{meta}</span>}
                </span>
                <ChevronRight className="size-4 shrink-0 text-ink-faint group-hover:text-plum" aria-hidden="true" />
              </span>
            </Link>
          </li>
        );
      })}
    </ul>
  );
}
