import type { Page } from "@/types/content";
import { getArticlesByIds, getFaqsInGroup, getPageTrail } from "@/lib/content";
import { displayTitle } from "@/lib/site-config";
import { faqJsonLd, jsonLd } from "@/lib/seo";
import { Breadcrumbs } from "@/components/ui/Breadcrumbs";
import { ArticleBody } from "@/components/article/ArticleBody";
import { ArticleList, toListItem } from "@/components/article/ArticleList";
import { TableOfContents } from "@/components/article/TableOfContents";
import { LinkGrid } from "./LinkGrid";
import { VideoLibrary } from "./VideoLibrary";
import { FaqSection } from "./FaqSection";

const INTRO: Partial<Record<Page["kind"], string>> = {
  videos: "Pick a video from the list to play it.",
  hub: "Choose a section.",
  faq: "Quick answers to common questions about Plum POS, payments and Plum Core.",
};

/** Renders a WordPress page according to the structure the exporter found in it. */
export function PageView({ page }: { page: Page }) {
  const trail = getPageTrail(page);
  const title = displayTitle(page.title);
  const htmlBlock = page.blocks.find((b) => b.kind === "html");
  const faqs = page.blocks.flatMap((b) => (b.kind === "faq" ? getFaqsInGroup(b.group) : []));

  return (
    <div className="mx-auto max-w-7xl px-4 pt-6 sm:px-6 lg:pt-10">
      <Breadcrumbs items={[...trail.map((p) => ({ name: displayTitle(p.title), url: p.url })), { name: title, url: page.url }]} />
      <header className="mt-6 max-w-3xl">
        <h1 className="font-display text-[2rem] font-bold leading-tight tracking-tight sm:text-[2.6rem]">{title}</h1>
        {INTRO[page.kind] && <p className="mt-3 text-lg text-ink-soft">{INTRO[page.kind]}</p>}
      </header>

      <div className="mt-10 space-y-12">
        {page.blocks.map((b, i) => {
          switch (b.kind) {
            case "heading":
              // FAQ headings are rendered by their FaqSection.
              return page.kind === "faq" ? null : <h2 key={i} className="font-display text-2xl font-semibold">{displayTitle(b.text)}</h2>;
            case "text":
              return <div key={i} className="max-w-3xl"><ArticleBody html={b.html} /></div>;
            case "links":
              return <LinkGrid key={i} block={b} />;
            case "videos":
              return <VideoLibrary key={i} videos={b.items} pageUrl={page.url} />;
            case "articles": {
              const items = getArticlesByIds(b.articleIds).map(toListItem);
              return <div key={i} className="max-w-4xl"><ArticleList items={items} showExcerpt /></div>;
            }
            case "faq":
              return <FaqSection key={i} title={b.title} faqs={getFaqsInGroup(b.group)} />;
            case "html":
              return (
                <div key={i} className="grid gap-10 lg:grid-cols-[minmax(0,1fr)_14rem]">
                  <ArticleBody html={b.html} />
                  {b.toc.length > 1 && <aside className="hidden lg:block"><div className="sticky top-24"><TableOfContents items={b.toc} /></div></aside>}
                </div>
              );
          }
        })}
        {htmlBlock === undefined && page.blocks.length === 0 && <p className="text-ink-soft">This page has no content yet.</p>}
      </div>
      {faqs.length > 0 && <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: jsonLd(faqJsonLd(faqs)) }} />}
    </div>
  );
}
