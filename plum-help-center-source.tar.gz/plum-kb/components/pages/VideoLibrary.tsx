"use client";

import { useEffect, useRef, useState } from "react";
import { Play } from "lucide-react";
import { track } from "@/lib/analytics";

type Video = { id: string; title: string; src: string };

/**
 * One player plus a playlist, instead of dozens of <video> elements.
 * Each video has a deep link (#video-id) so search results can open it.
 */
export function VideoLibrary({ videos, pageUrl }: { videos: Video[]; pageUrl: string }) {
  const [current, setCurrent] = useState(0);
  const playerRef = useRef<HTMLVideoElement>(null);
  const tracked = useRef(new Set<string>());

  useEffect(() => {
    const select = () => {
      const i = videos.findIndex((v) => `#${v.id}` === window.location.hash);
      if (i >= 0) {
        setCurrent(i);
        document.getElementById("player")?.scrollIntoView({ block: "start" });
      }
    };
    select();
    window.addEventListener("hashchange", select);
    return () => window.removeEventListener("hashchange", select);
  }, [videos]);

  const video = videos[current];
  const choose = (i: number) => {
    setCurrent(i);
    history.replaceState(null, "", `#${videos[i].id}`);
    requestAnimationFrame(() => playerRef.current?.play().catch(() => {}));
  };

  return (
    <div className="grid gap-6 lg:grid-cols-[minmax(0,1fr)_20rem]">
      <div id="player" className="scroll-mt-24">
        <video
          key={video.src}
          ref={playerRef}
          src={video.src}
          controls
          playsInline
          preload="metadata"
          className="aspect-video w-full rounded-2xl border border-line bg-black"
          onPlay={() => {
            if (tracked.current.has(video.id)) return;
            tracked.current.add(video.id);
            track({ name: "video_played", url: `${pageUrl}#${video.id}`, title: video.title });
          }}
        >
          <track kind="captions" />
        </video>
        <h2 className="mt-4 font-display text-xl font-semibold" aria-live="polite">{video.title}</h2>
        <p className="mt-1 text-sm text-ink-faint">Video {current + 1} of {videos.length}</p>
      </div>

      {videos.length > 1 && (
        <nav aria-label="Videos in this section">
          <ol className="max-h-[32rem] space-y-1 overflow-y-auto rounded-2xl border border-line bg-surface p-2">
            {videos.map((v, i) => (
              <li key={v.id} id={v.id} className="scroll-mt-24">
                <button
                  type="button"
                  onClick={() => choose(i)}
                  aria-current={i === current ? "true" : undefined}
                  className="flex w-full items-start gap-3 rounded-xl px-3 py-2.5 text-left hover:bg-plum-wash aria-[current=true]:bg-plum-wash"
                >
                  <span className={`mt-0.5 flex size-6 shrink-0 items-center justify-center rounded-full text-xs font-semibold ${i === current ? "bg-plum text-paper" : "bg-plum-wash text-plum"}`}>
                    {i === current ? <Play className="size-3 fill-current" aria-hidden="true" /> : i + 1}
                  </span>
                  <span className={`leading-snug ${i === current ? "font-medium text-plum" : "text-ink"}`}>{v.title}</span>
                </button>
              </li>
            ))}
          </ol>
        </nav>
      )}
    </div>
  );
}
