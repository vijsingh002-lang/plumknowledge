"use client";

import { useEffect, useId, useRef, useState } from "react";
import { useRouter } from "next/navigation";
import { CornerDownLeft, Search, X } from "lucide-react";
import { track } from "@/lib/analytics";
import { SUGGESTED_SEARCHES } from "@/lib/site-config";
import { EmptyState, ErrorState, SkeletonRows } from "@/components/ui/States";
import { SearchResultItem } from "./SearchResultItem";
import { useSearch } from "./useSearch";
import { useChanged } from "@/hooks/useChanged";

type Props = { open: boolean; initialQuery: string; onClose: () => void };

/**
 * Command-palette style search. Native <dialog> provides focus trapping, Esc
 * and an inert background. The panel remounts on every opening, so each
 * search starts from a clean state.
 */
export function SearchDialog({ open, initialQuery, onClose }: Props) {
  const ref = useRef<HTMLDialogElement>(null);
  const [session, setSession] = useState(0);

  useEffect(() => {
    const d = ref.current;
    if (!d) return;
    if (open && !d.open) d.showModal();
    else if (!open && d.open) d.close();
  }, [open]);

  if (useChanged(open) && open) setSession((n) => n + 1);

  return (
    <dialog
      ref={ref}
      onClose={onClose}
      onClick={(e) => e.target === ref.current && onClose()}
      aria-label="Search the help center"
      className="m-0 h-dvh max-h-none w-full max-w-none bg-transparent p-0 backdrop:bg-ink/35 backdrop:backdrop-blur-[2px] sm:mx-auto sm:mt-[12vh] sm:h-auto sm:max-w-2xl sm:px-4"
    >
      {open && <SearchPanel key={session} initialQuery={initialQuery} onClose={onClose} />}
    </dialog>
  );
}

function SearchPanel({ initialQuery, onClose }: { initialQuery: string; onClose: () => void }) {
  const inputRef = useRef<HTMLInputElement>(null);
  const router = useRouter();
  const listId = useId();
  const [query, setQuery] = useState(initialQuery);
  const { status, hits, retry } = useSearch(query, { limit: 12 });
  // The highlighted row belongs to one result set; a new set starts at the top.
  const [selection, setSelection] = useState({ hits, index: 0 });
  const active = selection.hits === hits ? selection.index : 0;
  const setActive = (update: (i: number) => number) => setSelection({ hits, index: update(active) });

  useEffect(() => {
    requestAnimationFrame(() => inputRef.current?.select());
  }, []);

  const go = (i: number) => {
    const hit = hits[i];
    if (!hit) return;
    track({ name: "search_result_clicked", query, url: hit.url, position: i + 1 });
    onClose();
    router.push(hit.url);
  };

  const onKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "ArrowDown") {
      e.preventDefault();
      setActive((a) => Math.min(a + 1, hits.length - 1));
    } else if (e.key === "ArrowUp") {
      e.preventDefault();
      setActive((a) => Math.max(a - 1, 0));
    } else if (e.key === "Enter") {
      e.preventDefault();
      if (hits[active]) go(active);
      else if (query.trim()) {
        onClose();
        router.push(`/search/?q=${encodeURIComponent(query.trim())}`);
      }
    }
  };

  useEffect(() => {
    document.getElementById(`${listId}-${active}`)?.scrollIntoView({ block: "nearest" });
  }, [active, listId]);

  return (
      <div className="flex h-full flex-col overflow-hidden border-line bg-surface sm:h-auto shadow-[0_24px_60px_-20px_rgb(30_16_38/0.45)] sm:max-h-[70vh] sm:rounded-2xl sm:border">
        <div className="flex items-center gap-3 border-b-2 border-line px-4 focus-within:border-plum">
          <Search className="size-5 shrink-0 text-plum" aria-hidden="true" />
          <input
            ref={inputRef}
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            onKeyDown={onKeyDown}
            placeholder="Search articles, videos and FAQs"
            aria-label="Search"
            role="combobox"
            aria-expanded={hits.length > 0}
            aria-controls={listId}
            aria-activedescendant={hits.length ? `${listId}-${active}` : undefined}
            aria-autocomplete="list"
            autoComplete="off"
            spellCheck={false}
            maxLength={100}
            className="h-14 min-w-0 flex-1 bg-transparent text-[1.05rem] text-ink outline-none placeholder:text-ink-faint focus-visible:outline-none"
          />
          <button type="button" onClick={onClose} className="rounded-md p-1.5 text-ink-soft hover:bg-plum-wash hover:text-ink" aria-label="Close search">
            <X className="size-5" aria-hidden="true" />
          </button>
        </div>

        <div className="min-h-0 flex-1 overflow-y-auto overscroll-contain p-2" aria-live="polite">
          {status === "idle" && (
            <div className="px-3 py-4">
              <p className="text-sm text-ink-soft">Try a topic</p>
              <div className="mt-2 flex flex-wrap gap-2">
                {SUGGESTED_SEARCHES.map((s) => (
                  <button key={s} type="button" onClick={() => setQuery(s)} className="rounded-full border border-line px-3 py-1 text-sm hover:border-plum hover:text-plum">
                    {s}
                  </button>
                ))}
              </div>
            </div>
          )}
          {status === "loading" && <SkeletonRows rows={4} />}
          {status === "error" && <div className="p-2"><ErrorState onRetry={retry} /></div>}
          {status === "ready" && hits.length === 0 && (
            <div className="p-2">
              <EmptyState title={`No results for "${query.trim()}"`}>Check the spelling, or try a shorter term such as a device or screen name.</EmptyState>
            </div>
          )}
          {status === "ready" && hits.length > 0 && (
            <div id={listId} role="listbox" aria-label="Search results">
              {hits.map((h, i) => (
                <SearchResultItem key={h.id} id={`${listId}-${i}`} hit={h} active={i === active} onHover={() => setActive(() => i)} onSelect={() => { track({ name: "search_result_clicked", query, url: h.url, position: i + 1 }); onClose(); }} />
              ))}
            </div>
          )}
        </div>

        <div className="hidden items-center justify-between gap-4 border-t border-line px-4 py-2.5 text-xs text-ink-faint sm:flex">
          <span className="flex items-center gap-3">
            <span><kbd className="rounded border border-line px-1">↑</kbd> <kbd className="rounded border border-line px-1">↓</kbd> to move</span>
            <span className="flex items-center gap-1"><kbd className="rounded border border-line px-1"><CornerDownLeft className="inline size-3" aria-hidden="true" /></kbd> to open</span>
            <span><kbd className="rounded border border-line px-1">Esc</kbd> to close</span>
          </span>
          {query.trim() && (
            <button type="button" className="text-plum hover:underline" onClick={() => { onClose(); router.push(`/search/?q=${encodeURIComponent(query.trim())}`); }}>
              See all results
            </button>
          )}
        </div>
      </div>
  );
}
