"use client";

import { useEffect, useState } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { Search } from "lucide-react";
import { SUGGESTED_SEARCHES } from "@/lib/site-config";
import { EmptyState, ErrorState, SkeletonRows } from "@/components/ui/States";
import { SearchResultItem } from "./SearchResultItem";
import { useChanged } from "@/hooks/useChanged";
import { useSearch } from "./useSearch";

export function SearchPageClient() {
  const params = useSearchParams();
  const router = useRouter();
  const initial = (params.get("q") ?? "").slice(0, 100);
  const [query, setQuery] = useState(initial);
  const { status, hits, retry } = useSearch(query, { limit: 50 });

  // Follow external navigation to /search/?q=… (e.g. "See all results" in the dialog).
  if (useChanged(initial) && initial !== query.trim()) setQuery(initial);

  // Keep the URL shareable without adding history entries on every keystroke.
  useEffect(() => {
    const t = window.setTimeout(() => {
      const q = query.trim();
      router.replace(q ? `/search/?q=${encodeURIComponent(q)}` : "/search/", { scroll: false });
    }, 400);
    return () => window.clearTimeout(t);
  }, [query, router]);

  return (
    <div>
      <form role="search" onSubmit={(e) => e.preventDefault()} className="relative">
        <Search className="pointer-events-none absolute left-4 top-1/2 size-5 -translate-y-1/2 text-plum" aria-hidden="true" />
        <input
          type="search"
          name="q"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Search articles, videos and FAQs"
          aria-label="Search the help center"
          maxLength={100}
          autoFocus
          className="h-14 w-full rounded-2xl border border-line-strong bg-surface pl-12 pr-4 text-lg outline-none placeholder:text-ink-faint focus:border-plum"
        />
      </form>

      <div className="mt-8" aria-live="polite">
        {status === "idle" && (
          <div className="flex flex-wrap items-center gap-2">
            <span className="text-sm text-ink-soft">Try:</span>
            {SUGGESTED_SEARCHES.map((s) => (
              <button key={s} type="button" onClick={() => setQuery(s)} className="rounded-full border border-line px-3 py-1 text-sm hover:border-plum hover:text-plum">{s}</button>
            ))}
          </div>
        )}
        {status === "loading" && <SkeletonRows rows={6} />}
        {status === "error" && <ErrorState onRetry={retry} />}
        {status === "ready" && !hits.length && (
          <EmptyState title="No articles found.">Try searching with different keywords, such as the name of a screen, report or device.</EmptyState>
        )}
        {status === "ready" && hits.length > 0 && (
          <>
            <p className="mb-3 text-sm text-ink-soft">{hits.length === 50 ? "Top 50" : hits.length} result{hits.length === 1 ? "" : "s"}</p>
            <div className="space-y-1">
              {hits.map((h) => <SearchResultItem key={h.id} hit={h} showSnippet />)}
            </div>
          </>
        )}
      </div>
    </div>
  );
}
