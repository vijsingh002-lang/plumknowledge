"use client";

import { createContext, useCallback, useContext, useEffect, useState, type ReactNode } from "react";
import { SearchDialog } from "./SearchDialog";

type Ctx = { openSearch: (initial?: string) => void };
const SearchContext = createContext<Ctx>({ openSearch: () => {} });
export const useSearchDialog = () => useContext(SearchContext);

/** Owns the global search dialog and its keyboard shortcuts (Ctrl/⌘ + K, and "/"). */
export function SearchProvider({ children }: { children: ReactNode }) {
  const [open, setOpen] = useState(false);
  const [initial, setInitial] = useState("");

  const openSearch = useCallback((q = "") => {
    setInitial(q);
    setOpen(true);
  }, []);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const typing = e.target instanceof HTMLElement && (e.target.isContentEditable || /^(INPUT|TEXTAREA|SELECT)$/.test(e.target.tagName));
      if ((e.key === "k" || e.key === "K") && (e.ctrlKey || e.metaKey)) {
        e.preventDefault();
        setOpen((o) => !o);
      } else if (e.key === "/" && !typing && !open) {
        e.preventDefault();
        openSearch();
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [open, openSearch]);

  return (
    <SearchContext.Provider value={{ openSearch }}>
      {children}
      <SearchDialog open={open} initialQuery={initial} onClose={() => setOpen(false)} />
    </SearchContext.Provider>
  );
}
