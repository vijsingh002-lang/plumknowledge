import Link from "next/link";
import { CircleHelp, FileText, Folder, LayoutGrid, PlayCircle } from "lucide-react";
import { formatMonth } from "@/lib/format";
import { highlight, snippet, type Hit, type Segment } from "./engine";

const TYPE = {
  article: { icon: FileText, label: "Article" },
  faq: { icon: CircleHelp, label: "FAQ" },
  video: { icon: PlayCircle, label: "Video" },
  category: { icon: Folder, label: "Category" },
  page: { icon: LayoutGrid, label: "Guide" },
} as const;

export const Highlighted = ({ segments }: { segments: Segment[] }) => (
  <>{segments.map((s, i) => (s.match ? <mark key={i} className="hl">{s.text}</mark> : <span key={i}>{s.text}</span>))}</>
);

type Props = {
  hit: Hit;
  active?: boolean;
  id?: string;
  showSnippet?: boolean;
  onSelect?: () => void;
  onHover?: () => void;
};

export function SearchResultItem({ hit, active, id, showSnippet, onSelect, onHover }: Props) {
  const { icon: Icon, label } = TYPE[hit.type];
  const excerpt = showSnippet && hit.text ? snippet(hit.text, hit.terms) : "";
  return (
    <Link
      id={id}
      href={hit.url}
      role={id ? "option" : undefined}
      aria-selected={id ? active : undefined}
      onClick={onSelect}
      onMouseMove={onHover}
      className={`flex gap-3 rounded-lg px-3 py-2.5 outline-none transition-colors ${active ? "bg-plum-wash" : "hover:bg-plum-wash/60"}`}
    >
      <Icon className={`mt-0.5 size-4 shrink-0 ${active ? "text-plum" : "text-ink-faint"}`} aria-hidden="true" />
      <span className="min-w-0 flex-1">
        <span className="block font-medium leading-snug text-ink">
          <Highlighted segments={highlight(hit.title, hit.terms)} />
        </span>
        {excerpt && (
          <span className="mt-0.5 line-clamp-2 block text-sm text-ink-soft">
            <Highlighted segments={highlight(excerpt, hit.terms)} />
          </span>
        )}
        <span className="mt-0.5 flex flex-wrap gap-x-2 text-xs text-ink-faint">
          <span className="sr-only">{label}, </span>
          <span className="truncate">{hit.crumb}</span>
          {hit.updatedAt && <span>Updated {formatMonth(hit.updatedAt)}</span>}
        </span>
      </span>
    </Link>
  );
}
