"use client";

import { Search } from "lucide-react";
import { useSearchDialog } from "./SearchProvider";
import { useClientValue } from "@/hooks/useStoredValue";

export function SearchTrigger({ variant = "bar" }: { variant?: "bar" | "icon" }) {
  const { openSearch } = useSearchDialog();
  const mod = useClientValue(() => (/Mac|iPhone|iPad/.test(navigator.platform) ? "⌘" : "Ctrl"), "Ctrl");

  if (variant === "icon") {
    return (
      <button type="button" onClick={() => openSearch()} className="rounded-lg p-2 text-ink-soft hover:bg-plum-wash hover:text-ink" aria-label="Search">
        <Search className="size-5" aria-hidden="true" />
      </button>
    );
  }
  return (
    <button
      type="button"
      onClick={() => openSearch()}
      aria-keyshortcuts="Control+K Meta+K"
      className="flex h-9 w-56 items-center gap-2 rounded-lg border border-line bg-surface px-3 text-sm text-ink-faint transition-colors hover:border-line-strong hover:text-ink-soft"
    >
      <Search className="size-4" aria-hidden="true" />
      <span className="flex-1 text-left">Search</span>
      <kbd className="rounded border border-line px-1.5 font-sans text-[0.7rem]">{mod} K</kbd>
    </button>
  );
}
