import MiniSearch, { type SearchResult } from "minisearch";
import type { SearchDoc } from "@/types/search";

/**
 * Client-side search engine. The index file is fetched once, on first use,
 * and shared by the dialog and the search page.
 */
let enginePromise: Promise<MiniSearch<SearchDoc>> | null = null;

export function loadEngine(): Promise<MiniSearch<SearchDoc>> {
  enginePromise ??= fetch("/search-index.json", { credentials: "omit" })
    .then((r) => {
      if (!r.ok) throw new Error(`Search index returned ${r.status}`);
      return r.json() as Promise<SearchDoc[]>;
    })
    .then((docs) => {
      if (!Array.isArray(docs)) throw new Error("Search index is malformed");
      const ms = new MiniSearch<SearchDoc>({
        fields: ["title", "keywords", "crumb", "text"],
        storeFields: ["type", "title", "url", "crumb", "text", "updatedAt"],
        searchOptions: { boost: { title: 5, keywords: 2, crumb: 1.5 }, prefix: true, fuzzy: (term) => (term.length > 4 ? 0.2 : false), combineWith: "AND" },
      });
      ms.addAll(docs);
      return ms;
    })
    .catch((err) => {
      enginePromise = null; // allow retry
      throw err;
    });
  return enginePromise;
}

export type Hit = SearchDoc & { score: number; terms: string[] };

const TYPE_WEIGHT: Record<SearchDoc["type"], number> = { article: 1.15, category: 1.1, faq: 1, page: 0.9, video: 0.85 };

export function runSearch(ms: MiniSearch<SearchDoc>, query: string, limit = 20): Hit[] {
  const q = query.trim().slice(0, 100);
  if (!q) return [];
  let results: SearchResult[] = ms.search(q);
  if (!results.length) results = ms.search(q, { combineWith: "OR" }); // loosen before giving up
  return results
    .map((r) => ({ ...(r as unknown as SearchDoc), id: String(r.id), score: r.score * TYPE_WEIGHT[r.type as SearchDoc["type"]], terms: r.terms }))
    .sort((a, b) => b.score - a.score)
    .slice(0, limit);
}

/* ── highlighting helpers (return segments; React renders them, no HTML injection) ── */

const escapeRe = (s: string) => s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");

export type Segment = { text: string; match: boolean };

export function highlight(text: string, terms: string[]): Segment[] {
  const words = [...new Set(terms.filter((t) => t.length > 1))].sort((a, b) => b.length - a.length);
  if (!words.length) return [{ text, match: false }];
  // With a capturing group, split() puts the matches at odd indices.
  return text
    .split(new RegExp(`(${words.map(escapeRe).join("|")})`, "gi"))
    .map((part, i) => ({ text: part, match: i % 2 === 1 }))
    .filter((s) => s.text);
}

export function snippet(text: string, terms: string[], radius = 90): string {
  if (!text) return "";
  const lower = text.toLowerCase();
  const pos = terms.map((t) => lower.indexOf(t.toLowerCase())).filter((i) => i >= 0).sort((a, b) => a - b)[0];
  if (pos === undefined) return text.slice(0, radius * 2) + (text.length > radius * 2 ? "…" : "");
  const start = Math.max(0, text.lastIndexOf(" ", Math.max(0, pos - radius)));
  const end = Math.min(text.length, text.indexOf(" ", pos + radius) === -1 ? text.length : text.indexOf(" ", pos + radius));
  return `${start > 0 ? "…" : ""}${text.slice(start, end).trim()}${end < text.length ? "…" : ""}`;
}
