"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { track } from "@/lib/analytics";
import { loadEngine, runSearch, type Hit } from "./engine";

export type SearchStatus = "idle" | "loading" | "ready" | "error";

/** Debounced search against the lazily loaded client index. */
export function useSearch(query: string, { enabled = true, debounceMs = 140, limit = 20 } = {}) {
  const [status, setStatus] = useState<SearchStatus>("idle");
  const [hits, setHits] = useState<Hit[]>([]);
  const [attempt, setAttempt] = useState(0);
  const lastTracked = useRef("");

  useEffect(() => {
    if (!enabled) return;
    let cancelled = false;
    const q = query.trim();
    const timer = window.setTimeout(
      async () => {
        if (!q) {
          setHits([]);
          setStatus("idle");
          return;
        }
        setStatus((s) => (s === "ready" ? s : "loading"));
        try {
          const engine = await loadEngine();
          if (cancelled) return;
          const results = runSearch(engine, q, limit);
          setHits(results);
          setStatus("ready");
          if (q.length > 2 && q !== lastTracked.current) {
            lastTracked.current = q;
            track({ name: "search_performed", query: q, results: results.length });
          }
        } catch {
          if (!cancelled) setStatus("error");
        }
      },
      q ? debounceMs : 0,
    );
    return () => {
      cancelled = true;
      window.clearTimeout(timer);
    };
  }, [query, enabled, debounceMs, limit, attempt]);

  const retry = useCallback(() => setAttempt((n) => n + 1), []);
  return { status, hits, retry };
}
