import Link from "next/link";
import { ChevronRight } from "lucide-react";
import { breadcrumbJsonLd, jsonLd } from "@/lib/seo";

export type Crumb = { name: string; url: string };

/** Breadcrumb trail; the last crumb is the current page. Also emits BreadcrumbList JSON-LD. */
export function Breadcrumbs({ items }: { items: Crumb[] }) {
  const all = [{ name: "Help Center", url: "/" }, ...items];
  return (
    <nav aria-label="Breadcrumb" className="no-print">
      <ol className="flex flex-wrap items-center gap-x-1 gap-y-1 text-sm text-ink-soft">
        {all.map((c, i) => {
          const last = i === all.length - 1;
          return (
            <li key={c.url + i} className="flex items-center gap-1">
              {i > 0 && <ChevronRight className="size-3.5 text-ink-faint" aria-hidden="true" />}
              {last ? (
                <span aria-current="page" className="max-w-[28ch] truncate text-ink">{c.name}</span>
              ) : (
                <Link href={c.url} className="rounded hover:text-plum hover:underline">{c.name}</Link>
              )}
            </li>
          );
        })}
      </ol>
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: jsonLd(breadcrumbJsonLd(all)) }} />
    </nav>
  );
}
