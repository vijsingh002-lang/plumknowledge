import { presentationFor } from "@/lib/site-config";
import { CategoryIconClient } from "@/components/layout/CategoryIconClient";

/** Icon for a category, looked up by slug. */
export function CategoryIcon({ slug, className }: { slug: string; className?: string }) {
  return <CategoryIconClient icon={presentationFor(slug).icon} className={className} />;
}
