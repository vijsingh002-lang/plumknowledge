import Link from "next/link";
import { BRAND } from "@/lib/site-config";

/** The Plum brand mark (icon extracted from the official Plum logo). */
export function PlumGlyph({ className = "size-7" }: { className?: string }) {
  // eslint-disable-next-line @next/next/no-img-element -- tiny static brand asset, no optimization needed
  return <img src="/brand/plum-icon.png" alt="" width={28} height={28} className={className} />;
}

export function Logo() {
  return (
    <Link href="/" className="group flex items-center gap-2.5 rounded-md" aria-label={`${BRAND.title}, home`}>
      <PlumGlyph />
      <span className="flex items-baseline gap-1.5 leading-none">
        <span className="font-display text-[1.15rem] font-bold text-ink">{BRAND.product}</span>
        <span className="hidden text-[0.95rem] text-ink-soft sm:inline">{BRAND.shortTitle}</span>
      </span>
    </Link>
  );
}
