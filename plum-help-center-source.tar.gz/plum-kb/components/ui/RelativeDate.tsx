"use client";

import { formatDate, relativeTime } from "@/lib/format";
import { useClientValue } from "@/hooks/useStoredValue";

/**
 * Static HTML shows the absolute date (always correct); in the browser it
 * becomes "3 days ago", since only the browser knows what "now" is.
 */
export function RelativeDate({ iso, prefix = "" }: { iso: string; prefix?: string }) {
  const label = useClientValue(() => relativeTime(iso), formatDate(iso));
  return (
    <time dateTime={iso} title={formatDate(iso)}>
      {prefix}
      {label}
    </time>
  );
}
