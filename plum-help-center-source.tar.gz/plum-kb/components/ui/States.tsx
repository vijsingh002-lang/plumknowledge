import type { ReactNode } from "react";
import { SearchX, TriangleAlert } from "lucide-react";

export function EmptyState({ title, children, icon }: { title: string; children?: ReactNode; icon?: ReactNode }) {
  return (
    <div className="rounded-xl border border-dashed border-line-strong px-6 py-10 text-center">
      <div className="mx-auto mb-3 flex size-10 items-center justify-center rounded-full bg-plum-wash text-plum">
        {icon ?? <SearchX className="size-5" aria-hidden="true" />}
      </div>
      <p className="font-display text-lg font-semibold">{title}</p>
      {children && <div className="mx-auto mt-1.5 max-w-md text-ink-soft">{children}</div>}
    </div>
  );
}

export function ErrorState({ title = "Search couldn't load.", onRetry }: { title?: string; onRetry?: () => void }) {
  return (
    <div role="alert" className="rounded-xl border border-line bg-amber-wash px-5 py-6 text-center">
      <TriangleAlert className="mx-auto mb-2 size-5 text-amber" aria-hidden="true" />
      <p className="font-semibold">{title}</p>
      <p className="mt-1 text-sm text-ink-soft">Check your connection, then try again.</p>
      {onRetry && (
        <button type="button" onClick={onRetry} className="mt-3 rounded-lg border border-line-strong bg-surface px-3.5 py-1.5 text-sm font-medium hover:border-plum">
          Try again
        </button>
      )}
    </div>
  );
}

export function SkeletonRows({ rows = 4 }: { rows?: number }) {
  return (
    <ul aria-hidden="true" className="space-y-2">
      {Array.from({ length: rows }, (_, i) => (
        <li key={i} className="rounded-lg px-3 py-3">
          <div className="h-4 w-2/3 animate-pulse rounded bg-line" />
          <div className="mt-2 h-3 w-1/3 animate-pulse rounded bg-line/70" />
        </li>
      ))}
    </ul>
  );
}
