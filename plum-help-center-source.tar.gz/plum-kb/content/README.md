# Generated content

These files are produced by `npm run export:content` from the WordPress
database. They are committed so the site can be built without database access,
but they are generated artifacts — edit content in WordPress and re-export,
don't hand-edit these.

- `articles.json`, `pages.json`, `faqs.json` — sanitized content
- `categories.json`, `tags.json`, `navigation.json`, `site.json` — structure
- `redirects.json` — URL redirect map (compiled to deploy/ configs by `npm run gen:deploy`)
