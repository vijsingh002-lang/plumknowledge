# Architecture

## Overview

The help center is a **static site generated from a build-time export of WordPress**. There is no runtime dependency on WordPress, PHP, or a database. This is the key architectural decision, made because the source WordPress install was compromised (see `SECURITY.md`): removing all server-side code removes the class of vulnerability that was exploited.

```
WordPress DB + uploads ──▶ exporter ──▶ content/*.json + public/media ──▶ Next.js build ──▶ ./out (static) ──▶ CDN / nginx / Apache
```

## Why static export over live headless

The brief offered three data strategies. After inspecting the source (a compromised install with unauthenticated remote-code-execution backdoors) the live options were rejected:

- **Option A (live WordPress REST API):** would put the new frontend on top of the same exploited server; a single point of failure and an active attack surface.
- **Option B (custom API):** same server-exposure problem.
- **Option C (migrate the data):** chosen. Content is extracted once into a clean, validated, static form. The public site has no server to attack, needs no secrets at runtime, and is trivially cacheable.

Editors keep using WordPress (rebuilt cleanly, on a private network); the export is re-run when content changes.

## Data flow and the content contract

`types/content.ts` defines Zod schemas for every content type (Article, Category, Tag, Faq, Page, Redirect, …). These schemas are the contract:

- The **exporter** (`scripts/export-wordpress.ts`) produces JSON shaped to them.
- The **data layer** (`lib/content.ts`) parses `content/*.json` through them at build time. A malformed export throws during `next build`, so broken data can never reach production.

The UI never imports raw JSON; it only calls typed functions in `lib/`.

## The export pipeline (`scripts/`)

`export-wordpress.ts` orchestrates; the `wp/` modules each do one job:

| Module | Responsibility |
|---|---|
| `wp/shortcodes.ts` | Parse Avada/Fusion and WordPress shortcodes into a tree. Only real shortcode names are parsed; text like "click Accept [button]" is left alone. |
| `wp/wpautop.ts` | Port of WordPress `wpautop()` so classic-editor paragraph breaks render correctly. |
| `wp/html.ts` | Convert shortcodes to HTML, clean Google-Sites/Avada markup, build the table of contents, mark "Step N:" and callouts, and **sanitize against a strict allowlist**. |
| `wp/media.ts` | Resolve upload URLs, **re-encode** each image to responsive WebP with `sharp`, record missing files. |
| `wp/pages.ts` | Classify Avada builder pages into structured blocks (hub / videos / listing / faq / content). |
| `wp/exclusions.ts` | The documented list of attacker-created content to drop, plus legacy URL aliases. |

`generate-deploy.ts` turns `content/redirects.json` into nginx/Apache redirect files.

## The application (`app/`, `components/`, `lib/`)

Rendering is almost entirely server components (static). Client components are used only where interaction requires it: search, theme toggle, menus, the video player, feedback, copy/print, and relative dates.

### Routes

| Route | Renders | Source |
|---|---|---|
| `/` | Homepage | `app/page.tsx` |
| `/[...path]/` | Article **or** page (they share WordPress's `/slug/` namespace) | `app/[...path]/page.tsx` |
| `/category/[...path]/` | Category (nested) | `app/category/[...path]/page.tsx` |
| `/tag/[slug]/` | Tag listing | `app/tag/[slug]/page.tsx` |
| `/search/` | Full search page | `app/search/page.tsx` |
| `/search-index.json` | Client search index (static) | `app/search-index.json/route.ts` |
| `/sitemap.xml`, `/robots.txt` | SEO | `app/sitemap.ts`, `app/robots.ts` |
| `/404` | Not found | `app/not-found.tsx` |

All routes use `generateStaticParams` with `dynamicParams = false`, so exactly the known URLs are pre-rendered (134 pages).

### Component groups (`components/`)

- **layout/** — `SiteHeader`, `SiteFooter`, `BrowseMenu`, `MobileNav`, `ThemeToggle`, theme bootstrap.
- **search/** — `SearchProvider` (Ctrl/⌘-K), `SearchDialog`, `SearchPageClient`, the MiniSearch `engine`, `useSearch` hook, result item.
- **article/** — `ArticleView` and its parts: body, table of contents (sticky + mobile), actions (copy/print), feedback, related, prev/next, article list.
- **pages/** — `PageView` and block renderers: `LinkGrid` (hubs), `VideoLibrary`, `FaqSection`.
- **home/** — hero, "Start here" ticket, category directory, article columns.
- **ui/** — `Logo`, `CategoryIcon`, `Breadcrumbs`, `States` (loading/empty/error), `RelativeDate`.

### Key libraries (`lib/`)

- `content.ts` — the only entry point to content; validated loaders and queries.
- `ranking.ts` — related articles, prev/next, and "popular" (by inbound links, since there is no analytics data — documented in the file).
- `seo.ts` — metadata, canonical URLs, Open Graph, and JSON-LD (Article, FAQ, Breadcrumb, WebSite).
- `search-index.ts` — flattens all content into search documents.
- `analytics.ts` — provider-neutral event tracking.
- `site-config.ts` — presentation config: brand, category icons/descriptions, nav labels. New copy lives here, separate from exported content.

## Search

Search runs entirely in the browser. `/search-index.json` (a static file emitted at build time) is fetched once, indexed with MiniSearch, and shared by the Ctrl-K dialog and the `/search/` page. Matching covers titles, headings, category/tag names, and body text, with prefix and light fuzzy matching, debounced input, and loading/empty/error states.

## Accessibility and theming

- Semantic landmarks, skip link, visible focus, keyboard-operable search (arrow keys, Enter, Esc) and menus.
- Native `<dialog>` for search and mobile nav (focus trapping and Esc for free), native `<details>` for FAQs and the mobile ToC.
- Light/dark/system themes via CSS variables, applied before first paint to avoid a flash, and persisted in `localStorage`.
- `prefers-reduced-motion` respected.
