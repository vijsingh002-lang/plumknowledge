# Deployment

The build output in `./out` is a static site. Host it anywhere that serves static files. Whatever the host, apply the **redirects** and **security headers** below.

## Build

```bash
npm ci
npm run build     # -> ./out, and regenerates deploy/redirects.{nginx,apache}.conf
```

## Self-hosted nginx or Apache

Sample vhosts: `deploy/nginx.conf`, `deploy/apache.conf`. They already include the generated redirect maps and the headers below, and they disable PHP execution for the site.

1. Put the repo at `/var/www/plum-help-center` (so `./out` and `./deploy` sit side by side).
2. Point the vhost `root`/`DocumentRoot` at `/var/www/plum-help-center/out`.
3. Add your TLS certificates (the sample configs leave certificate paths to your TLS tooling / certbot).
4. Reload the server.

Update flow: `git pull` (or upload) → `npm ci && npm run build` → reload. Because filenames under `/_next/static/` are content-hashed, they are served `immutable` for a year; HTML is served fresh.

## Static hosts / CDN (S3+CloudFront, Netlify, Vercel static, etc.)

1. Upload `./out`.
2. Recreate the redirects from `content/redirects.json` in the host's redirect config (`_redirects`, CloudFront Functions, etc.). `deploy/redirects.*.conf` are ready-made references.
3. Set the response headers below (edge function or host header config).
4. Serve `404.html` for unknown paths and map `/slug/` to `/slug/index.html`.

## Security headers (required)

```
Strict-Transport-Security: max-age=63072000; includeSubDomains; preload
X-Content-Type-Options: nosniff
Referrer-Policy: strict-origin-when-cross-origin
X-Frame-Options: SAMEORIGIN
Permissions-Policy: geolocation=(), microphone=(), camera=(), interest-cohort=()
Content-Security-Policy: default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; font-src 'self'; media-src 'self' https://altametricslist.com; frame-src https://www.youtube-nocookie.com https://player.vimeo.com; connect-src 'self'; frame-ancestors 'self'; base-uri 'self'; form-action 'self'; object-src 'none'
```

Notes:
- `style-src 'unsafe-inline'` is required by Next.js's inlined critical CSS. All JavaScript is external and first-party, so `script-src` stays `'self'` with no inline allowance.
- `media-src` allows the training-video host `altametricslist.com`. If videos move, update it here and in the exporter's `ALLOWED_VIDEO_HOSTS`.

## Enabling Google Analytics 4 (optional)

1. Set `NEXT_PUBLIC_GA_MEASUREMENT_ID=G-XXXXXXXXXX` and add a GA loader (e.g. `@next/third-parties`) in `app/layout.tsx`. Analytics events are already emitted to `window.dataLayer` by `lib/analytics.ts`.
2. Extend the CSP:
   - `script-src`: add `https://www.googletagmanager.com`
   - `img-src`: add `https://www.googletagmanager.com https://*.google-analytics.com`
   - `connect-src`: add `https://*.google-analytics.com https://*.analytics.google.com https://www.googletagmanager.com`

## Smoke test after deploy

- `/` loads; Ctrl-K search opens and returns results.
- An article renders with working images/links; light/dark toggle persists.
- An old date URL (e.g. `/2025/09/08/unboxing-and-setting-up-the-plum-pos-terminal/`) 301-redirects.
- `/wp-login.php` returns 410; `/sitemap.xml` and `/robots.txt` load.
- Response headers include the CSP above (check with `curl -I`).
