# Migration

Source: WordPress "Plumpos Platform" (Avada/Fusion theme), database dump `plum_platform_2026-09-23.sql` and `wp-content/uploads` from the release tarball.

## What was migrated

| Content | Source (WordPress) | Result | Count |
|---|---|---|---|
| Articles | `wp_posts` where `post_type='post'`, `post_status='publish'` | Article pages at `/slug/` | 66 |
| Pages | `wp_posts` where `post_type='page'` | Rebuilt as hub / video / listing / FAQ / content pages | 36 |
| FAQs | `wp_posts` where `post_type='avada_faq'` | FAQ accordion at `/faq/` | 77 |
| Categories | `wp_term_taxonomy` taxonomy `category` (+ `wp_terms`, `wp_term_relationships`) | Nested category pages | 39 (23 with articles) |
| Tags | taxonomy `post_tag` | Tag pages | kept where non-empty |
| FAQ groups | taxonomy `faq_category` | FAQ section headings | 3 |
| Navigation | `wp_posts` `nav_menu_item` + `wp_postmeta` ("Seo Main Menu") | Header/footer nav | 5 items |
| Media | `wp-content/uploads`, referenced in content and `_thumbnail_id` | Re-encoded WebP in `public/media` | 115 of 344 present |
| Training videos | MP4 URLs (host `altametricslist.com`) inside Fusion `[fusion_video]` shortcodes | Video library pages | ~130 videos |

### Database tables used

`wp_posts`, `wp_postmeta`, `wp_terms`, `wp_term_taxonomy`, `wp_term_relationships`, `wp_users`, `wp_options`. Plugin/analytics tables (`wp_aioseo_*`, `wp_actionscheduler_*`, `wp_monsterinsights_*`, `wp_fusion_*`, `wp_mdf_*`, etc.) were inspected and **not** needed:

- **AIOSEO** (`wp_aioseo_posts`): no custom titles or descriptions were set, so per-page metadata is generated from titles and excerpts instead.
- **MonsterInsights**: installed but never connected to a Google Analytics property — no historical data exists.

## What was excluded

- **6 attacker-created posts** (all titled "x", IDs 3026/3032/3038/3044/3053/3063), created via the webshell backdoors during the compromise. Listed in `scripts/wp/exclusions.ts`; each is served a `410 Gone`.
- **`uncategorized`** default category, revisions, autosaves, and the default "Hello world" comment / spam comments (comments are not shown on the new site).
- **WordPress server endpoints** (`/wp-admin`, `/wp-login.php`, `/xmlrpc.php`, `/wp-json/`, feeds): gone, returned as `410`.
- The `home` and `mdtf-results-page` pages, replaced by the new homepage and search.

The exporter checks whether any surviving content was modified after the compromise began (2026-08-01); none was (last legitimate edit: 2026-06-25).

## Content transformation

WordPress content mixed Fusion page-builder shortcodes, Google-Docs/Sites paste markup, and classic-editor HTML. The exporter:

1. Parses shortcodes; converts meaningful ones (`fusion_title` → heading, `fusion_imageframe` → image, `fusion_video` → video, `caption`, `fusion_faq`/`fusion_blog` → structured blocks); unwraps layout wrappers. Literal bracketed words in instructions ("click Accept [button]") are preserved.
2. Applies `wpautop()` so paragraph breaks render.
3. Strips Google-Sites `<div>`/`<span>` soup, normalizes heading levels (article H1 is the title; body starts at H2), and promotes bold-only paragraphs to headings only where an article otherwise has no structure.
4. Marks "Step N:" paragraphs and Note/Warning/Tip callouts for styling.
5. Re-encodes every image to responsive WebP; missing files become a labelled placeholder.
6. **Sanitizes** the result against a strict tag/attribute allowlist (`sanitize-html`): no scripts, styles, event handlers, or iframe/video sources outside YouTube/Vimeo/`altametricslist.com`.

## URLs and redirects

Existing `/%postname%/` URLs are preserved. All redirects are in `content/redirects.json` and compiled to `deploy/redirects.{nginx,apache}.conf` by `npm run gen:deploy`.

| Old URL pattern | New URL | Type | Count |
|---|---|---|---|
| `/YYYY/MM/DD/slug/` (old date permalinks) | `/slug/` | 301 | 66 |
| `/category/<child>/` (short category URLs) | `/category/<parent>/<child>/` | 301 | 27 |
| Empty category URLs | nearest non-empty ancestor (or `/`) | 301 | 16 |
| `/faq-items/<slug>/` | `/faq/#<slug>` | 301 | 77 |
| `/different-types-of-ordering/` | `/plum-pos-guide/` (renamed page) | 301 | 1 |
| `/online-ordering/` article (collided with video page) | `/online-ordering-article/` | 301 | 1 |
| `/home/`, `/mdtf-results-page/` | `/`, `/search/` | 301 | 2 |
| `/wp-admin`, `/wp-login.php`, `/xmlrpc.php`, feeds, author archives | `410` (or `/`) | 410/301 | 8 |
| Attacker posts (`/x/`, `/x-2/`, …) | `410 Gone` | 410 | 6 |

**One intentional URL change:** the article formerly at `/online-ordering/` moved to `/online-ordering-article/` because a *page* already owns that slug, and WordPress itself resolved the page first. A 301 preserves any inbound links.

## Feature parity checklist

| Feature | Old site | New site |
|---|---|---|
| Articles | Yes | Yes |
| Categories (nested) | Yes | Yes |
| Tags | Yes | Yes |
| Search | Yes (theme search) | Yes (client-side, Ctrl-K + `/search/`) |
| Media/images | Yes | Yes (re-encoded; missing files flagged) |
| Training videos | Yes | Yes (dedicated player + playlist) |
| FAQs | Yes | Yes (accordion, deep-linkable) |
| Navigation | Yes | Yes (dynamic from WordPress menu) |
| Shortcodes | Yes | Converted at build time |
| SEO metadata | Partial (defaults) | Yes (titles, canonical, OG, JSON-LD, sitemap) |
| Analytics | Installed, not collecting | Provider-neutral hooks, ready to enable |
| User login | Not used on public site | Not applicable (static) |
| Feedback ("was this helpful") | No | Yes (analytics event) |
| Comments | Default/spam only | Removed |

## After restoring media

232 referenced images were missing because the uploaded tarball was truncated (all of `2025/09`, including the logo). They become labelled "Screenshot unavailable" placeholders. To restore: put a clean, pre-August-2026 copy of `wp-content/uploads` at `WP_UPLOADS_DIR`, re-run `npm run export:content && npm run build`. The full list is in `migration-report/missing-media.md`.
