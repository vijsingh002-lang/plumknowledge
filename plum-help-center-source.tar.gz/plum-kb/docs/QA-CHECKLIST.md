# QA checklist

Run against a production build (`npm run build && npm run start`, or the deployed site).

## UI & visual
- [ ] Homepage: hero, search, "Start here" ticket, category directory, popular/recent, videos/FAQ panels all render.
- [ ] Consistent type, spacing and color across pages; no overflow or clipped text.
- [ ] Category cards: whole card is clickable; article sub-links work; hover state shows.
- [ ] No layout shift on load; fonts do not flash.

## Responsive
- [ ] Mobile (~375px): hamburger menu opens/closes; nav and category list usable; no horizontal scroll.
- [ ] Article body readable on mobile; tables scroll within their container, not the page.
- [ ] Tablet (~768px) and desktop (≥1024px): article shows category nav and/or table of contents appropriately.
- [ ] Wide tables, code blocks and images stay within the content column.

## Search
- [ ] Ctrl/⌘-K opens the dialog anywhere; `/` opens it when not typing; Esc closes.
- [ ] Typing shows debounced results; arrow keys move; Enter opens the highlighted result.
- [ ] "See all results" and `/search/` page work; `?q=` is shareable.
- [ ] Loading (skeleton), empty ("No articles found"), and error states appear correctly.
- [ ] Matching terms are highlighted; results link to the right article/faq/video/category.

## Articles
- [ ] Title, updated date, reading time, breadcrumbs correct.
- [ ] Headings, lists, tables, callouts, "Step N" styling render.
- [ ] Table of contents tracks the current section while scrolling; mobile ToC collapses.
- [ ] Copy link copies the URL; Print opens a clean print view.
- [ ] "Was this helpful?" records a vote and remembers it on reload.
- [ ] Related articles and previous/next are relevant and link correctly.

## Categories, tags, pages
- [ ] Category page: breadcrumbs, subcategories, article count, in-category filter.
- [ ] Empty categories redirect (no dead pages).
- [ ] Tag pages list the right articles.
- [ ] Hub pages show tiles; video pages play and switch via the playlist; deep links (`#video-id`) open the right video.
- [ ] FAQ page: accordion opens/closes; deep links (`/faq/#slug`) open and scroll to the question.

## Images & media
- [ ] Present images load, are responsive, and have alt text; lazy-load below the fold.
- [ ] Missing images show the "Screenshot unavailable" placeholder, not a broken icon.
- [ ] Videos load from the allowed host and play with controls.

## Links & redirects
- [ ] Internal links resolve (no 404s); external links open in a new tab with `rel="noopener"`.
- [ ] Old date-based URLs, short category URLs, `/faq-items/…`, and renamed pages 301 to the right place.
- [ ] Attacker posts and WordPress endpoints return 410.

## SEO
- [ ] Unique `<title>` and meta description per page; canonical URL correct.
- [ ] Open Graph / Twitter tags present; OG image loads.
- [ ] JSON-LD valid (Article, FAQ, Breadcrumb, WebSite) — test in Google Rich Results.
- [ ] `sitemap.xml` and `robots.txt` correct; `/search/` is noindex.
- [ ] One `<h1>` per page; heading order sensible.

## Accessibility (target WCAG 2.1 AA)
- [ ] Keyboard-only: can reach and operate nav, search, menus, accordions, video list.
- [ ] Visible focus everywhere; skip-to-content link works.
- [ ] Screen reader: landmarks, breadcrumb `aria-current`, dialog labels, live regions on search.
- [ ] Color contrast passes in light and dark themes.
- [ ] `prefers-reduced-motion` disables non-essential motion.
- [ ] Automated pass (axe / Lighthouse) with no serious violations.

## Themes
- [ ] Light/dark/system cycle works and persists; no flash of wrong theme on reload.
- [ ] Images, tables, callouts and code readable in both themes.

## Performance
- [ ] Lighthouse (mobile) Performance ≥ 90; good LCP/CLS.
- [ ] Static assets cached (immutable `/_next/static/`); images are WebP and sized.
- [ ] No console errors (other than blocked third-party video in restricted networks).

## Cross-browser
- [ ] Chrome, Edge, Firefox, Safari (desktop) and iOS Safari + Android Chrome (mobile).

## Security (see SECURITY.md / DEPLOYMENT.md)
- [ ] Response headers include the CSP and other security headers.
- [ ] No secrets in the client bundle; no `/wp-*` endpoints reachable.
- [ ] No mixed content; everything over HTTPS.
