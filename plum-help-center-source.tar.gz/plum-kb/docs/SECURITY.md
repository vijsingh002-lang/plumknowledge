# Security

## The source site was compromised

Analysis of the uploaded WordPress code and database found an active compromise. This shaped the whole rebuild.

**Findings (as of the 2026-09-23 database dump):**

- **8 webshell plugins** in `wp-content/plugins/` (`cache-optimizer-*`, `content-tools-*`) providing unauthenticated remote code execution, `wp-config.php`/`.env` "harvest" routines, direct database access, and privilege-escalation probes. One (`content-tools-cf8d5cb323`) was still in the active-plugins list.
- **9 rogue administrator accounts** created 2026-08-01 to 08-05 (`ppadmins*`, `w2s_*@wp2shell.local`), matching the webshell install times.
- **6 exploit test posts** (all titled "x") created through the backdoors.
- Attacker "proof" links referencing a public `wp2shell` exploit lab.

Only `ppadmin` and `cgoswami` appear to be legitimate accounts. Legitimate knowledge-base content was **not** modified after the compromise began (last real edit: 2026-06-25).

## How the rebuild responds

1. **No server-side code ships.** The production site is static files only — no PHP, no database, no WordPress. The exploited attack surface does not exist in the new deployment.
2. **Attacker content is excluded** by ID, and its URLs return `410 Gone` (`scripts/wp/exclusions.ts`).
3. **The exporter reads the database read-only** (`SET SESSION TRANSACTION READ ONLY`) and the setup uses a **SELECT-only** database user. It never writes to WordPress.
4. **Every image is re-encoded** with `sharp`, which strips metadata and defeats polyglot/appended-payload tricks. Non-images are rejected.
5. **All HTML is sanitized** at build time against a strict allowlist (`scripts/wp/html.ts`): no `<script>`, inline event handlers, `style`, `javascript:` URLs, `<object>`/`<embed>`, or `<form>`. Iframes are limited to YouTube-nocookie and Vimeo; videos to `altametricslist.com`.
6. **Strict Content-Security-Policy** and other security headers are set by the web server (`deploy/`, `docs/DEPLOYMENT.md`): `default-src 'self'`, `object-src 'none'`, no inline scripts.
7. **No secrets in the frontend.** Database credentials are used only by the exporter on the build machine, via `.env.local` (git-ignored). `.env.example` documents them. The public bundle contains no credentials.

## Recommended remediation for the WordPress source (separate from this frontend)

The old site is offline, which is correct. Before it is ever used again (for editing only, on a private network):

1. **Rebuild, don't clean.** Reinstall WordPress core and all plugins from fresh downloads on a clean host; migrate only sanitized content. Do not restore the compromised filesystem.
2. **Rotate every secret** that the harvest routine could read: DB password, WordPress salts/keys, and any `.env` values. Treat them all as leaked.
3. **Delete the 9 rogue admin accounts**; reset passwords and sessions for the real accounts; enable 2FA.
4. **Investigate the host**, given the privilege-escalation tooling: check the DB server (`10.151.0.91`) and web host for new system users, cron jobs, and SSH keys. Consider professional incident response.
5. **Find the entry point** (first shell appeared 2026-08-01) and patch it before going back online.
6. **Keep the compromised files and access logs** for forensics.
7. **Keep WordPress off the public internet.** With this static frontend, WordPress only needs to be reachable by editors and the build machine.

## Reporting

If you find a security issue in this frontend, contact the Altametrics engineering team rather than filing it publicly.
