"use client";

import { useState } from "react";

/**
 * Returns true during the render in which `value` changed.
 * (React's recommended alternative to setState-in-effect for prop changes.)
 */
export function useChanged<T>(value: T): boolean {
  const [prev, setPrev] = useState(value);
  if (prev !== value) {
    setPrev(value);
    return true;
  }
  return false;
}
