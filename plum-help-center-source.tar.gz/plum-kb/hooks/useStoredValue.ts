"use client";

import { useCallback, useSyncExternalStore } from "react";

const EVENT = "kb-storage";

function subscribe(callback: () => void) {
  window.addEventListener("storage", callback);
  window.addEventListener(EVENT, callback);
  return () => {
    window.removeEventListener("storage", callback);
    window.removeEventListener(EVENT, callback);
  };
}

const read = (key: string) => {
  try {
    return localStorage.getItem(key);
  } catch {
    return null; // storage disabled (private mode, policies)
  }
};

/**
 * A localStorage value as React state, synced across components and tabs.
 * Renders `null` on the server and during hydration, so static HTML never
 * depends on per-visitor data.
 */
export function useStoredValue(key: string): [string | null, (value: string) => void] {
  const value = useSyncExternalStore(subscribe, () => read(key), () => null);
  const set = useCallback(
    (next: string) => {
      try {
        localStorage.setItem(key, next);
      } catch {}
      window.dispatchEvent(new Event(EVENT));
    },
    [key],
  );
  return [value, set];
}

const noop = () => () => {};

/** A value that only exists in the browser (e.g. platform), with a server fallback. */
export function useClientValue<T>(getClient: () => T, serverValue: T): T {
  return useSyncExternalStore(noop, getClient, () => serverValue);
}

