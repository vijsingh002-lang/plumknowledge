/**
 * Provider-neutral analytics. Components call `track()`; nothing here knows
 * about a vendor. Events are pushed to `window.dataLayer` (read by Google Tag
 * Manager / GA4 if you add it) and re-dispatched as a DOM event so any other
 * provider can subscribe:
 *
 *   window.addEventListener("kb:analytics", (e) => myProvider.send(e.detail))
 */
export type AnalyticsEvent =
  | { name: "search_performed"; query: string; results: number }
  | { name: "search_result_clicked"; query: string; url: string; position: number }
  | { name: "article_opened"; url: string; title: string }
  | { name: "category_opened"; url: string; category: string }
  | { name: "feedback_submitted"; url: string; helpful: boolean }
  | { name: "related_article_clicked"; from: string; to: string }
  | { name: "video_played"; url: string; title: string };

declare global {
  interface Window {
    dataLayer?: Record<string, unknown>[];
  }
}

export function track(event: AnalyticsEvent): void {
  if (typeof window === "undefined") return;
  try {
    const { name, ...params } = event;
    (window.dataLayer ??= []).push({ event: name, ...params });
    window.dispatchEvent(new CustomEvent("kb:analytics", { detail: event }));
  } catch {
    // Analytics must never break the page.
  }
}
