/**
 * Content repository. The single entry point to exported WordPress content.
 * Server-only: never import this from a "use client" component (it would
 * bundle every article into the browser).
 */
import { z } from "zod";
import articlesJson from "@/content/articles.json";
import categoriesJson from "@/content/categories.json";
import tagsJson from "@/content/tags.json";
import faqsJson from "@/content/faqs.json";
import pagesJson from "@/content/pages.json";
import navigationJson from "@/content/navigation.json";
import siteJson from "@/content/site.json";
import redirectsJson from "@/content/redirects.json";
import {
  ArticleSchema,
  CategorySchema,
  FaqSchema,
  NavItemSchema,
  PageSchema,
  RedirectSchema,
  SiteSchema,
  TagSchema,
  type Article,
  type Category,
  type Faq,
  type Page,
  type Tag,
} from "@/types/content";

function parse<T>(schema: z.ZodType<T>, data: unknown, name: string): T {
  const result = schema.safeParse(data);
  if (!result.success) {
    throw new Error(`content/${name} failed validation:\n${z.prettifyError(result.error)}`);
  }
  return result.data;
}

const articles = parse(z.array(ArticleSchema), articlesJson, "articles.json");
const categories = parse(z.array(CategorySchema), categoriesJson, "categories.json");
const tags = parse(z.array(TagSchema), tagsJson, "tags.json");
const faqs = parse(z.array(FaqSchema), faqsJson, "faqs.json");
const pages = parse(z.array(PageSchema), pagesJson, "pages.json");
const navigation = parse(z.array(NavItemSchema), navigationJson, "navigation.json");
const site = parse(SiteSchema, siteJson, "site.json");
const redirects = parse(z.array(RedirectSchema), redirectsJson, "redirects.json");

const byUrl = new Map<string, Article | Page>([...articles, ...pages].map((x) => [x.url, x]));
const categoryById = new Map(categories.map((c) => [c.id, c]));

/* ── site ─────────────────────────────────────────────────────── */
export const getSite = () => site;
export const getNavigation = () => navigation;
export const getRedirects = () => redirects;

/* ── articles ─────────────────────────────────────────────────── */
export const getArticles = () => articles;
export const getArticleById = (id: number) => articles.find((a) => a.id === id);
export const getArticlesByIds = (ids: number[]) => ids.map(getArticleById).filter((a): a is Article => !!a);

/** Resolves a URL path ("/foo/" or "/a/b/") to an article or page. */
export function getEntryByPath(segments: string[]): { type: "article"; entry: Article } | { type: "page"; entry: Page } | null {
  const hit = byUrl.get(`/${segments.join("/")}/`);
  if (!hit) return null;
  return "html" in hit ? { type: "article", entry: hit as Article } : { type: "page", entry: hit as Page };
}

export function getAllEntryPaths(): string[][] {
  return [...byUrl.keys()].map((u) => u.split("/").filter(Boolean));
}

export function getRecentlyUpdated(limit = 6): Article[] {
  return [...articles].sort((a, b) => b.updatedAt.localeCompare(a.updatedAt)).slice(0, limit);
}

/* ── categories ───────────────────────────────────────────────── */
export const getCategories = () => categories;
export const getCategoryById = (id: number | null) => (id == null ? undefined : categoryById.get(id));
export const getCategoryByPath = (path: string[]) => categories.find((c) => c.path.join("/") === path.join("/"));

export function getTopCategories(): Category[] {
  return categories.filter((c) => c.parentId === null && c.articleCount > 0);
}

export function getChildCategories(id: number): Category[] {
  return categories.filter((c) => c.parentId === id && c.articleCount > 0).sort((a, b) => a.name.localeCompare(b.name));
}

export function getCategoryTrail(id: number | null): Category[] {
  const trail: Category[] = [];
  let cur = getCategoryById(id);
  while (cur) {
    trail.unshift(cur);
    cur = getCategoryById(cur.parentId);
  }
  return trail;
}

function descendantIds(id: number): Set<number> {
  const out = new Set([id]);
  for (const c of categories) if (c.parentId === id) for (const d of descendantIds(c.id)) out.add(d);
  return out;
}

/** Articles in a category or any of its subcategories, oldest first (authoring order). */
export function getArticlesInCategory(id: number): Article[] {
  const ids = descendantIds(id);
  return articles.filter((a) => a.categoryIds.some((c) => ids.has(c))).sort((a, b) => a.publishedAt.localeCompare(b.publishedAt));
}

/* ── tags ─────────────────────────────────────────────────────── */
export const getTags = () => tags;
export const getTagBySlug = (slug: string) => tags.find((t) => t.slug === slug);
export const getArticlesWithTag = (tag: Tag) => articles.filter((a) => a.tagIds.includes(tag.id));
export const getTagsForArticle = (a: Article) => tags.filter((t) => a.tagIds.includes(t.id));

/* ── pages / faqs ─────────────────────────────────────────────── */
export const getPages = () => pages;
export const getPageByUrl = (url: string) => pages.find((p) => p.url === url);
export const getFaqs = () => faqs;
export const getFaqsInGroup = (group: string): Faq[] => faqs.filter((f) => f.groups.includes(group)).sort((a, b) => a.order - b.order || a.id - b.id);

/** Parent chain for builder pages (Training videos → Plum POS → Manager videos → …). */
export function getPageTrail(page: Page): Page[] {
  const trail: Page[] = [];
  const seen = new Set<number>();
  let cur = page.parentUrl ? getPageByUrl(page.parentUrl) : undefined;
  while (cur && !seen.has(cur.id)) {
    seen.add(cur.id);
    trail.unshift(cur);
    cur = cur.parentUrl ? getPageByUrl(cur.parentUrl) : undefined;
  }
  return trail;
}

export function getAllVideos() {
  return pages.flatMap((p) =>
    p.blocks.flatMap((b) => (b.kind === "videos" ? b.items.map((v) => ({ ...v, pageUrl: p.url, pageTitle: p.title })) : [])),
  );
}
