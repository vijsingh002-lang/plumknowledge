import type { Article } from "@/types/content";
import { getArticles, getArticlesInCategory, getCategoryById } from "./content";

/**
 * "Popular" without analytics.
 *
 * The WordPress site has no page-view data (MonsterInsights was installed
 * but never connected to a Google Analytics property). As a proxy, an
 * article's popularity is how often the rest of the help center points to
 * it: links from other articles and from hub pages. Ties go to the most
 * recently updated article. Swap `score` for real view counts once
 * analytics is collecting data.
 */
export function getPopularArticles(limit = 6): Article[] {
  const score = (a: Article) => a.inboundLinks;
  return [...getArticles()]
    .sort((a, b) => score(b) - score(a) || b.updatedAt.localeCompare(a.updatedAt))
    .slice(0, limit);
}

const STOP = new Set(["how", "to", "the", "a", "an", "in", "of", "and", "or", "for", "on", "is", "what", "plum", "pos", "guide", "add", "your", "with", "do", "i", "we"]);
const terms = (s: string) => new Set(s.toLowerCase().split(/[^a-z0-9]+/).filter((w) => w.length > 2 && !STOP.has(w)));

/**
 * Related articles, scored on shared categories, tags, title keywords and
 * explicit links between the two articles.
 */
export function getRelatedArticles(article: Article, limit = 4): Article[] {
  const mine = terms(article.title);
  const parentOf = (id: number) => getCategoryById(id)?.parentId ?? id;
  const myParents = new Set(article.categoryIds.map(parentOf));

  return getArticles()
    .filter((o) => o.id !== article.id)
    .map((o) => {
      let s = 0;
      if (o.primaryCategoryId && o.primaryCategoryId === article.primaryCategoryId) s += 3;
      s += 2 * o.categoryIds.filter((c) => article.categoryIds.includes(c)).length;
      if (o.categoryIds.some((c) => myParents.has(parentOf(c)))) s += 1;
      s += 2 * o.tagIds.filter((t) => article.tagIds.includes(t)).length;
      const theirs = terms(o.title);
      const overlap = [...mine].filter((w) => theirs.has(w)).length;
      if (overlap) s += (4 * overlap) / new Set([...mine, ...theirs]).size;
      if (article.html.includes(`href="${o.url}"`) || o.html.includes(`href="${article.url}"`)) s += 2;
      return { o, s };
    })
    .filter((x) => x.s >= 2)
    .sort((a, b) => b.s - a.s || b.o.updatedAt.localeCompare(a.o.updatedAt))
    .slice(0, limit)
    .map((x) => x.o);
}

/** Previous/next within the article's primary category, in authoring order. */
export function getAdjacentArticles(article: Article): { prev?: Article; next?: Article } {
  if (!article.primaryCategoryId) return {};
  const list = getArticlesInCategory(article.primaryCategoryId);
  const i = list.findIndex((a) => a.id === article.id);
  return { prev: list[i - 1], next: list[i + 1] };
}
