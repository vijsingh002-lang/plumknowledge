import type { SearchDoc } from "@/types/search";
import { getAllVideos, getArticles, getCategories, getCategoryTrail, getFaqs, getPages, getPageTrail, getSite, getTagsForArticle } from "./content";
import { displayTitle } from "./site-config";

const TEXT_LIMIT = 3000;

/** Everything searchable, flattened for the client-side index. */
export function buildSearchDocuments(): SearchDoc[] {
  const docs: SearchDoc[] = [];
  const groupName = new Map(getSite().faqGroups.map((g) => [g.slug, g.name]));

  for (const a of getArticles()) {
    const trail = getCategoryTrail(a.primaryCategoryId);
    docs.push({
      id: `a${a.id}`,
      type: "article",
      title: a.title,
      url: a.url,
      crumb: trail.map((c) => displayTitle(c.name)).join(" / "),
      keywords: [...a.toc.map((t) => t.text), ...trail.map((c) => c.name), ...getTagsForArticle(a).map((t) => t.name)].join(" "),
      text: a.text.slice(0, TEXT_LIMIT),
      updatedAt: a.updatedAt,
    });
  }
  for (const f of getFaqs()) {
    docs.push({
      id: `f${f.id}`,
      type: "faq",
      title: f.question,
      url: `/faq/#${f.slug}`,
      crumb: `FAQs / ${f.groups.map((g) => groupName.get(g) ?? g).join(", ")}`,
      keywords: f.groups.join(" "),
      text: f.text.slice(0, 1200),
    });
  }
  for (const v of getAllVideos()) {
    const page = getPages().find((p) => p.url === v.pageUrl)!;
    const trail = [...getPageTrail(page), page].map((p) => displayTitle(p.title));
    docs.push({ id: `v${v.pageUrl}${v.id}`, type: "video", title: v.title, url: `${v.pageUrl}#${v.id}`, crumb: trail.join(" / "), keywords: trail.join(" "), text: "" });
  }
  for (const c of getCategories().filter((c) => c.articleCount > 0)) {
    docs.push({ id: `c${c.id}`, type: "category", title: displayTitle(c.name), url: c.url, crumb: `${c.articleCount} article${c.articleCount === 1 ? "" : "s"}`, keywords: c.path.join(" "), text: c.description });
  }
  for (const p of getPages().filter((p) => p.kind === "hub" || p.kind === "listing" || p.kind === "content")) {
    docs.push({ id: `p${p.id}`, type: "page", title: displayTitle(p.title), url: p.url, crumb: getPageTrail(p).map((x) => displayTitle(x.title)).join(" / ") || "Help Center", keywords: "", text: p.text.slice(0, 600) });
  }
  return docs;
}
