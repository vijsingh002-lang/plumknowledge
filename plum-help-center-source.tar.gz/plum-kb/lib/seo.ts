import type { Metadata } from "next";
import type { Article, Category, Faq } from "@/types/content";
import { BRAND, SITE_URL } from "./site-config";

export const absoluteUrl = (path: string) => `${SITE_URL}${path.startsWith("/") ? path : `/${path}`}`;

type MetaInput = {
  title: string;
  description: string;
  path: string;
  type?: "website" | "article";
  image?: string | null;
  publishedTime?: string;
  modifiedTime?: string;
  noindex?: boolean;
};

export function buildMetadata(m: MetaInput): Metadata {
  const image = absoluteUrl(m.image || "/og-default.png");
  return {
    title: m.title,
    description: m.description,
    alternates: { canonical: absoluteUrl(m.path) },
    robots: m.noindex ? { index: false, follow: true } : undefined,
    openGraph: {
      type: m.type ?? "website",
      url: absoluteUrl(m.path),
      title: m.title,
      description: m.description,
      siteName: BRAND.title,
      images: [{ url: image }],
      ...(m.type === "article" ? { publishedTime: m.publishedTime, modifiedTime: m.modifiedTime } : {}),
    },
    twitter: { card: "summary_large_image", title: m.title, description: m.description, images: [image] },
  };
}

type Crumb = { name: string; url: string };

export const breadcrumbJsonLd = (crumbs: Crumb[]) => ({
  "@context": "https://schema.org",
  "@type": "BreadcrumbList",
  itemListElement: crumbs.map((c, i) => ({ "@type": "ListItem", position: i + 1, name: c.name, item: absoluteUrl(c.url) })),
});

export const articleJsonLd = (a: Article, category?: Category) => ({
  "@context": "https://schema.org",
  "@type": "TechArticle",
  headline: a.title,
  description: a.excerpt,
  datePublished: a.publishedAt,
  dateModified: a.updatedAt,
  mainEntityOfPage: absoluteUrl(a.url),
  image: a.ogImage ? absoluteUrl(a.ogImage) : undefined,
  articleSection: category?.name,
  publisher: { "@type": "Organization", name: BRAND.company },
});

export const faqJsonLd = (faqs: Faq[]) => ({
  "@context": "https://schema.org",
  "@type": "FAQPage",
  mainEntity: faqs.map((f) => ({ "@type": "Question", name: f.question, acceptedAnswer: { "@type": "Answer", text: f.text } })),
});

export const websiteJsonLd = () => ({
  "@context": "https://schema.org",
  "@type": "WebSite",
  name: BRAND.title,
  url: SITE_URL,
  potentialAction: { "@type": "SearchAction", target: `${SITE_URL}/search/?q={search_term_string}`, "query-input": "required name=search_term_string" },
});

/** Serialize JSON-LD safely for a <script> tag (no "</script>" breakout). */
export const jsonLd = (data: unknown) => JSON.stringify(data).replace(/</g, "\\u003c");
