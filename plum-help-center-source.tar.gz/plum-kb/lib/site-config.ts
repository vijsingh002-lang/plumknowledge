/**
 * Presentation settings for the help center.
 *
 * Content comes from WordPress; this file holds only how it is presented.
 * Category descriptions below are new copy written from each category's
 * article titles, because every WordPress category description was empty.
 * If a description is added in WordPress, the exported one wins.
 */

export const SITE_URL = (process.env.NEXT_PUBLIC_SITE_URL || "https://www.plumposplatform.com").replace(/\/$/, "");

export const BRAND = {
  product: "Plum Central",
  title: "Plum Central Help Center",
  shortTitle: "Help Center",
  company: "Altametrics",
  description:
    "Setup guides, how-to articles, training videos and answers for Plum POS, Plum Schedules, Plum Tunes, Zip Clock and the POS Dashboard.",
};

export type CategoryIconName =
  | "monitor"
  | "sliders"
  | "chart"
  | "calendar"
  | "music"
  | "clock"
  | "card"
  | "percent"
  | "wrench"
  | "rocket"
  | "folder";

export const CATEGORY_PRESENTATION: Record<string, { icon: CategoryIconName; description: string; order: number }> = {
  "getting-started": { icon: "rocket", order: 0, description: "Unbox the terminal, sign in, add terminals and take your store live." },
  "plum-pos-2": { icon: "monitor", order: 1, description: "Take orders, run quick sale and table service, manage employees and billing." },
  "pos-configuration": { icon: "sliders", order: 2, description: "Menu groups, items, portions, variations, events, locations and revenue centers." },
  "plum-pos-dashboard": { icon: "chart", order: 3, description: "Daily sales, menu mix, T-Log, tax exempt and employee sales reports." },
  pax: { icon: "card", order: 4, description: "Configure PAX payment devices, completion beeps and batch checks." },
  "auto-gratuity": { icon: "percent", order: 5, description: "Set up automatic fees and service charges on orders." },
  "plum-schedule": { icon: "calendar", order: 6, description: "Build shifts, apply labor rules, invite employees and manage permissions." },
  "zip-clock": { icon: "clock", order: 7, description: "Time clock setup, global settings and department management." },
  "plum-tunes": { icon: "music", order: 8, description: "In-store music: tracks, playlists, advertisement media and device activation." },
  "troubleshooting-on-pos": { icon: "wrench", order: 9, description: "Fixes for common issues on the POS terminal." },
};

export const presentationFor = (slug: string) =>
  CATEGORY_PRESENTATION[slug] ?? { icon: "folder" as const, description: "", order: 99 };

/** Friendlier labels for WordPress menu items. The URL is never changed. */
export const NAV_LABELS: Record<string, string> = {
  "/getting-started-with-plum-pos/": "Getting started",
  "/help-articles/": "Help articles",
  "/training-videos/": "Training videos",
  "/faq/": "FAQs",
};

/** WordPress accounts that are shared logins, not people; hidden as "author". */
export const GENERIC_AUTHORS = new Set(["ppadmin", "admin", "administrator"]);

/** Clean up WordPress-era titles for display (e.g. "Help Article(s)"). */
export function displayTitle(title: string): string {
  return title.replace(/\s*\((s)\)/gi, "s").replace(/\s+\?$/, "?").replace(/\bvidoes\b/gi, "videos").trim();
}

/**
 * "Start here" path on the homepage: the Getting Started articles in the
 * order a new store works through them (unbox → sign in → add terminals → go live).
 */
export const START_HERE_SLUGS = [
  "unboxing-and-setting-up-the-plum-pos-terminal",
  "how-to-login-into-plum-pos",
  "how-to-add-terminal-in-plum-pos",
  "comprehensive-guide-to-setup-and-go-live",
];

/** Suggested searches under the hero; each is a topic that returns results. */
export const SUGGESTED_SEARCHES = ["PAX", "Close day", "Refund", "Menu items", "Labor rules", "Playlist"];
