# Missing media

These images are referenced by content but were not found in `WP_UPLOADS_DIR`. Readers see a labelled "Screenshot unavailable" placeholder instead.
Restore the files from a clean (pre-August-2026) backup into the same paths and re-run `npm run export:content`.

| File (under wp-content/uploads) | Used on |
|---|---|
| `[external] https://lh3.googleusercontent.com/ezIy4NdwcvVBPhOW_LuiWOTt2VFrhMPuqwRiU5FscMg0kvQAt1mVxr4c` | /online-ordering-article/ |
| `[external] https://lh3.googleusercontent.com/wvOuk06NZ7UGwcSC2NKe1bH_4lUoZS3sLH_krMAsmALECRWIT7PK5PQS` | /online-ordering-article/ |
| `[external] https://lh4.googleusercontent.com/90yMX1Cv6E2vfCYtlJZh5ohx0Wfir-wYa2wiOECr-gZFBk196Veq8o2g` | /online-ordering-article/ |
| `[external] https://lh4.googleusercontent.com/I9vyv__SitPu4xhHZQErVTebjMzaMQY2VqS2CxDyox4MfwwbYWOgAuyt` | /online-ordering-article/ |
| `[external] https://lh5.googleusercontent.com/jthp5n_tFrpWQdbb2QeXT7M9zTTkOysnTlq0Jxshr7dVsjoxeskXxVvd` | /online-ordering-article/ |
| `[external] https://lh5.googleusercontent.com/VOTyccxpFBtZO2xM3hPMM1qEbKP7G3Cg8H1wEt5ojRYmUgSdvyTu3Mnf` | /online-ordering-article/ |
| `[external] https://lh6.googleusercontent.com/BJlv_tAwh6FcAUoILjEbdGq0WbAHKJivERulBOPutWgsixwHbUPmG183` | /online-ordering-article/ |
| `[external] https://lh6.googleusercontent.com/CmR0eiUQjWC4anU-MP-TT8CbcfV_6tJgRzyKRCPxybYymqK9aesmT3UD` | /online-ordering-article/ |
| `[external] https://lh7-rt.googleusercontent.com/docsd/ANYlcfA3bKKs5BHN9f8zke3Osw85-hSd9f1m17v6sq7XgNL` | /quick-sale-table-ordering/ |
| `[external] https://lh7-rt.googleusercontent.com/docsd/ANYlcfBG09WQcZHz92CKrXSHmZnSZ7skresnl2v6nDcTA2D` | /quick-sale-table-ordering/ |
| `[external] https://lh7-rt.googleusercontent.com/docsd/ANYlcfBYdtMSxzUf9_3_EYZxPjmJ-wYUTTVhfiMrZ3BXIIM` | /quick-sale-table-ordering/ |
| `[external] https://lh7-rt.googleusercontent.com/docsd/ANYlcfC1hhmFdxo7BhFSl8NCSYB8o_6OJ9PFtrcWFY18DKA` | /quick-sale-table-ordering/ |
| `[external] https://lh7-rt.googleusercontent.com/docsd/ANYlcfCtN8k__I6uRumot2ChDJo3NmPu3PCkIC7lOyGWOIb` | /quick-sale-table-ordering/ |
| `[external] https://lh7-rt.googleusercontent.com/docsd/ANYlcfCzTiQ1kcwGLqIR9iguH-_Ncs4QQpwX6I50vBnB2Cs` | /quick-sale-table-ordering/ |
| `[external] https://lh7-rt.googleusercontent.com/docsd/ANYlcfDBtB4TFCXjewLKdwVO9gI6hgdJlIsvxSpz4BEOluB` | /quick-sale-table-ordering/ |
| `[external] https://lh7-rt.googleusercontent.com/docsd/ANYlcfDsD9mIS8_S-pj7bZA3JAr2qg97PXHM5_mH_Nolkl-` | /quick-sale-table-ordering/ |
| `https://www.plumposplatform.com/wp-content/uploads/2025/09/brooke-cagle-WHWYBmtn3_0-unsplash.jpg` | /how-to-add-terminal-in-plum-pos/ (featured image) |
| `https://www.plumposplatform.com/wp-content/uploads/2025/09/online-ordering.jpg` | /unboxing-and-setting-up-the-plum-pos-terminal/ (featured image) |
| `https://www.plumposplatform.com/wp-content/uploads/2025/10/1-scaled.webp` | /comprehensive-guide-to-setup-and-go-live/ (featured image) |
| `https://www.plumposplatform.com/wp-content/uploads/2025/10/article3.webp` | /quick-sale-table-ordering/ (featured image), /online-ordering-article/ (featured image), /step-by-step-guide-to-add-employees-in-pos/ (featured image), /how-to-add-previous-years-sales/ (featured image) +37 |
| `https://www.plumposplatform.com/wp-content/uploads/2025/10/Onboarding_EmployeeSetup.png` | /how-to-login-into-plum-pos/ (featured image) |
