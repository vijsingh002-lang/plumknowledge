import type { NextConfig } from "next";

/**
 * Fully static export: `next build` writes plain HTML/CSS/JS to /out.
 * There is no Node server, database, or WordPress in production, so there
 * is no server-side attack surface. Redirects and security headers are
 * applied by the web server (see /deploy).
 */
const nextConfig: NextConfig = {
  output: "export",
  trailingSlash: true, // preserve WordPress's /slug/ URLs exactly
  images: { unoptimized: true }, // images are pre-optimized by the exporter
  poweredByHeader: false,
  reactStrictMode: true,
};

export default nextConfig;
