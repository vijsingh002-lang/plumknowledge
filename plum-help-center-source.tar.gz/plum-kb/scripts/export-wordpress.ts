/**
 * WordPress -> static content exporter.
 *
 *   npm run export:content
 *
 * Reads a WordPress database (read-only SELECTs only) plus its uploads folder
 * and writes sanitized JSON to /content and re-encoded images to /public/media.
 * The public site never talks to WordPress or a database.
 *
 * Configure through .env.local (see .env.example).
 */
import fs from "node:fs";
import path from "node:path";
import mysql, { type RowDataPacket } from "mysql2/promise";
import * as cheerio from "cheerio";
import { cleanHtml, slugify, sanitize } from "./wp/html";
import { MediaLibrary, type MediaAsset } from "./wp/media";
import { extractBlocks, classify, type RawBlock } from "./wp/pages";
import { EXCLUDED_POST_IDS, REPLACED_PAGES, EXCLUDED_CATEGORY_SLUGS, COMPROMISE_START, LEGACY_ALIASES } from "./wp/exclusions";
import type { Article, Category, Faq, NavItem, Page, PageBlock, Redirect, Site, Tag } from "../types/content";

/* ---------------- configuration ---------------- */

loadEnvFile(".env.local");
const env = (k: string, d?: string) => {
  const v = process.env[k] ?? d;
  if (v === undefined) throw new Error(`Missing environment variable ${k} (see .env.example)`);
  return v;
};
const ROOT = process.cwd();
const PREFIX = env("WP_TABLE_PREFIX", "wp_").replace(/[^a-zA-Z0-9_]/g, "");
const UPLOADS_DIR = path.resolve(env("WP_UPLOADS_DIR"));
const LEGACY_HOSTS = env("WP_LEGACY_HOSTS", "www.plumposplatform.com,plumposplatform.com,qa.plumposplatform.com").split(",").map((h) => h.trim().toLowerCase());
const CONTENT_DIR = path.join(ROOT, "content");
const MEDIA_DIR = path.join(ROOT, "public", "media");
const REPORT_DIR = path.join(ROOT, "migration-report");
const T = (name: string) => `\`${PREFIX}${name}\``;

type Row = RowDataPacket & Record<string, unknown>;
const decode = (s: string) => cheerio.load(`<p>${s}</p>`)("p").text().trim();
const iso = (d: unknown, fallback?: unknown): string => {
  const t = new Date(String(d).replace(" ", "T") + "Z");
  if (!Number.isNaN(t.getTime()) && t.getUTCFullYear() > 1970) return t.toISOString();
  return fallback !== undefined ? iso(fallback) : new Date(0).toISOString();
};

async function main() {
  const db = await mysql.createConnection({
    host: process.env.WP_DB_SOCKET ? undefined : env("WP_DB_HOST", "127.0.0.1"),
    port: Number(env("WP_DB_PORT", "3306")),
    socketPath: process.env.WP_DB_SOCKET || undefined,
    user: env("WP_DB_USER"),
    password: env("WP_DB_PASSWORD", ""),
    database: env("WP_DB_NAME"),
    charset: "utf8mb4",
    dateStrings: true, // keep WordPress's *_gmt values exactly as stored
  });
  // Belt and braces: this session cannot write, whatever the grants are.
  await db.query("SET SESSION TRANSACTION READ ONLY");
  const q = async (sql: string, params: unknown[] = []) => (await db.query<Row[]>(sql, params))[0];

  const media = new MediaLibrary(UPLOADS_DIR, MEDIA_DIR);
  const report = { excluded: [] as string[], reviewNeeded: [] as string[], brokenLinks: new Map<string, Set<string>>(), warnings: [] as string[] };

  /* ---------------- options ---------------- */
  const opt = async (name: string) => String((await q(`SELECT option_value FROM ${T("options")} WHERE option_name=?`, [name]))[0]?.option_value ?? "");
  const frontPageId = Number(await opt("page_on_front"));
  const site: Site = {
    name: decode(await opt("blogname")) || "Plum",
    tagline: decode(await opt("blogdescription")),
    legacyOrigin: `https://${LEGACY_HOSTS[0]}`,
    exportedAt: new Date().toISOString(),
    source: `WordPress database "${env("WP_DB_NAME")}"`,
    faqGroups: [],
  };

  /* ---------------- taxonomies ---------------- */
  const termRows = await q(
    `SELECT t.term_id, t.name, t.slug, tt.taxonomy, tt.parent, tt.description, tt.term_taxonomy_id
       FROM ${T("terms")} t JOIN ${T("term_taxonomy")} tt ON tt.term_id = t.term_id
      WHERE tt.taxonomy IN ('category','post_tag','faq_category')`,
  );
  const rels = await q(`SELECT object_id, term_taxonomy_id FROM ${T("term_relationships")}`);
  const termsByTT = new Map(termRows.map((r) => [Number(r.term_taxonomy_id), r]));
  const termsOf = (postId: number, taxonomy: string) =>
    rels.filter((r) => Number(r.object_id) === postId).map((r) => termsByTT.get(Number(r.term_taxonomy_id))).filter((t): t is Row => !!t && t.taxonomy === taxonomy);

  const catRows = termRows.filter((r) => r.taxonomy === "category" && !EXCLUDED_CATEGORY_SLUGS.has(String(r.slug)));
  const catById = new Map(catRows.map((r) => [Number(r.term_id), r]));
  const catPath = (id: number): string[] => {
    const r = catById.get(id);
    if (!r) return [];
    return [...(Number(r.parent) ? catPath(Number(r.parent)) : []), String(r.slug)];
  };

  /* ---------------- users ---------------- */
  const users = new Map((await q(`SELECT ID, display_name FROM ${T("users")}`)).map((u) => [Number(u.ID), String(u.display_name)]));

  /* ---------------- posts & pages ---------------- */
  const postRows = await q(
    `SELECT ID, post_author, post_title, post_name, post_content, post_excerpt, post_date, post_date_gmt, post_modified_gmt, post_modified, post_type, post_parent, menu_order
       FROM ${T("posts")} WHERE post_status='publish' AND post_type IN ('post','page','avada_faq') ORDER BY menu_order, ID`,
  );
  for (const r of postRows) {
    const id = Number(r.ID);
    if (EXCLUDED_POST_IDS.has(id)) {
      report.excluded.push(`${r.post_type} #${id} "${r.post_title}" /${r.post_name}/ (attacker-created during compromise)`);
      continue;
    }
    if (new Date(iso(r.post_modified_gmt)) >= COMPROMISE_START) report.reviewNeeded.push(`${r.post_type} #${id} "${r.post_title}" modified ${r.post_modified_gmt}`);
  }
  const live = postRows.filter((r) => !EXCLUDED_POST_IDS.has(Number(r.ID)));
  const posts = live.filter((r) => r.post_type === "post");
  const pages = live.filter((r) => r.post_type === "page" && Number(r.ID) !== frontPageId && !REPLACED_PAGES[String(r.post_name)]);
  const faqRows = live.filter((r) => r.post_type === "avada_faq");

  // URL plan: keep WordPress's /%postname%/ URLs. WordPress resolves a page
  // before a post with the same slug, so a colliding post gets a new URL.
  const pageSlugs = new Set(pages.map((p) => String(p.post_name)));
  const articleUrl = new Map<number, string>();
  for (const p of posts) {
    const slug = String(p.post_name);
    articleUrl.set(Number(p.ID), pageSlugs.has(slug) ? `/${slug}-article/` : `/${slug}/`);
  }
  const pageUrl = new Map<number, string>();
  const pageById = new Map(live.filter((r) => r.post_type === "page").map((r) => [Number(r.ID), r]));
  const pagePath = (id: number): string => {
    const r = pageById.get(id);
    if (!r) return "";
    return `${Number(r.post_parent) ? pagePath(Number(r.post_parent)) : ""}/${r.post_name}`;
  };
  for (const p of pages) pageUrl.set(Number(p.ID), `${pagePath(Number(p.ID))}/`);

  // Legacy path -> new path, used to rewrite links inside content.
  const linkMap = new Map<string, string>([["/", "/"]]);
  for (const p of posts) linkMap.set(`/${p.post_name}/`, articleUrl.get(Number(p.ID))!);
  for (const p of pages) linkMap.set(`/${p.post_name}/`, pageUrl.get(Number(p.ID))!).set(pageUrl.get(Number(p.ID))!, pageUrl.get(Number(p.ID))!);
  for (const [slug, to] of Object.entries(REPLACED_PAGES)) linkMap.set(`/${slug}/`, to);
  for (const c of catRows) {
    const url = `/category/${catPath(Number(c.term_id)).join("/")}/`;
    linkMap.set(url, url).set(`/category/${c.slug}/`, url);
  }
  for (const t of termRows.filter((r) => r.taxonomy === "post_tag")) linkMap.set(`/tag/${t.slug}/`, `/tag/${t.slug}/`);
  for (const f of faqRows) linkMap.set(`/faq-items/${f.post_name}/`, `/faq/#${f.post_name}`);
  for (const [from, to] of Object.entries(LEGACY_ALIASES)) linkMap.set(from, to);
  // Earlier the site used /%year%/%monthnum%/%day%/%postname%/ permalinks; those URLs still appear in content and search indexes.
  const datedUrl = (p: Row) => `/${String(p.post_date).slice(0, 10).replace(/-/g, "/")}/${p.post_name}/`;
  for (const p of posts) linkMap.set(datedUrl(p), articleUrl.get(Number(p.ID))!);

  const makeRewriter = (usedBy: string) => (href: string): string => {
    if (href.startsWith("#") || /^(mailto|tel):/i.test(href)) return href;
    let u: URL;
    try {
      u = new URL(href, site.legacyOrigin);
    } catch {
      return "#";
    }
    if (!LEGACY_HOSTS.includes(u.hostname.toLowerCase())) return u.toString();
    if (u.pathname.startsWith("/wp-content/uploads/")) return u.pathname; // images handled separately
    const p = u.searchParams.get("p") ?? u.searchParams.get("page_id");
    if (p) {
      const byId = articleUrl.get(Number(p)) ?? pageUrl.get(Number(p));
      if (byId) return byId;
    }
    const key = (u.pathname.endsWith("/") ? u.pathname : `${u.pathname}/`).toLowerCase();
    const lastSegment = `/${key.split("/").filter(Boolean).pop() ?? ""}/`;
    const mapped = linkMap.get(key) ?? (/^\/(category|\d{4})\//.test(key) ? linkMap.get(lastSegment) : undefined);
    if (mapped) return mapped + (mapped.includes("#") ? "" : u.hash);
    if (!report.brokenLinks.has(key)) report.brokenLinks.set(key, new Set());
    report.brokenLinks.get(key)!.add(usedBy);
    return key;
  };

  /* ---------------- articles ---------------- */
  console.log(`Exporting ${posts.length} articles…`);
  const articles: Article[] = [];
  const inbound = new Map<string, number>();
  for (const p of posts) {
    const id = Number(p.ID);
    const url = articleUrl.get(id)!;
    const cleaned = await cleanHtml(String(p.post_content), { media, usedBy: url, rewriteLink: makeRewriter(url) });
    for (const m of cleaned.html.matchAll(/href="(\/[^"#]*)/g)) if (m[1] !== url) inbound.set(m[1], (inbound.get(m[1]) ?? 0) + 1);

    const cats = termsOf(id, "category").filter((c) => catById.has(Number(c.term_id)));
    const primary = [...cats].sort((a, b) => catPath(Number(b.term_id)).length - catPath(Number(a.term_id)).length)[0];
    const words = cleaned.text.split(/\s+/).filter(Boolean).length;
    const og = await featuredImage(q, media, id, url);

    articles.push({
      id,
      slug: String(p.post_name),
      url,
      legacyUrl: `/${p.post_name}/`,
      title: decode(String(p.post_title)).replace(/\s+\?/g, "?").replace(/\s{2,}/g, " "),
      excerpt: excerpt(String(p.post_excerpt) || cleaned.text),
      html: cleaned.html,
      text: cleaned.text,
      toc: cleaned.toc,
      categoryIds: cats.map((c) => Number(c.term_id)),
      primaryCategoryId: primary ? Number(primary.term_id) : null,
      tagIds: termsOf(id, "post_tag").map((t) => Number(t.term_id)),
      author: users.get(Number(p.post_author)) ?? null,
      publishedAt: iso(p.post_date_gmt, p.post_modified_gmt),
      updatedAt: iso(p.post_modified_gmt),
      readingMinutes: Math.max(1, Math.round(words / 200)),
      wordCount: words,
      inboundLinks: 0,
      ogImage: og?.src ?? null,
    });
  }

  /* ---------------- categories & tags (counts from real, exported articles) ---------------- */
  const descendants = (id: number): number[] => [id, ...catRows.filter((c) => Number(c.parent) === id).flatMap((c) => descendants(Number(c.term_id)))];
  const categories: Category[] = catRows.map((c) => {
    const ids = new Set(descendants(Number(c.term_id)));
    return {
      id: Number(c.term_id),
      slug: String(c.slug),
      name: decode(String(c.name)),
      description: decode(String(c.description ?? "")),
      parentId: Number(c.parent) && catById.has(Number(c.parent)) ? Number(c.parent) : null,
      path: catPath(Number(c.term_id)),
      url: `/category/${catPath(Number(c.term_id)).join("/")}/`,
      articleCount: articles.filter((a) => a.categoryIds.some((x) => ids.has(x))).length,
    };
  });
  const tags: Tag[] = termRows
    .filter((r) => r.taxonomy === "post_tag")
    .map((t) => ({ id: Number(t.term_id), slug: String(t.slug), name: decode(String(t.name)), url: `/tag/${t.slug}/`, articleCount: articles.filter((a) => a.tagIds.includes(Number(t.term_id))).length }))
    .filter((t) => t.articleCount > 0);

  /* ---------------- FAQs ---------------- */
  const faqGroups = termRows.filter((r) => r.taxonomy === "faq_category");
  const faqs: Faq[] = [];
  for (const f of faqRows) {
    const cleaned = await cleanHtml(String(f.post_content), { media, usedBy: "/faq/", rewriteLink: makeRewriter("/faq/") });
    faqs.push({
      id: Number(f.ID),
      slug: String(f.post_name),
      question: decode(String(f.post_title)),
      html: cleaned.html,
      text: cleaned.text,
      groups: termsOf(Number(f.ID), "faq_category").map((t) => String(t.slug)),
      order: Number(f.menu_order),
    });
  }

  /* ---------------- pages ---------------- */
  console.log(`Exporting ${pages.length} pages…`);
  const exportedPages: Page[] = [];
  const catSlugSet = (slugs: string[]) => new Set(slugs.flatMap((s) => {
    const c = catRows.find((r) => r.slug === s);
    return c ? descendants(Number(c.term_id)) : [];
  }));
  for (const p of pages) {
    const id = Number(p.ID);
    const url = pageUrl.get(id)!;
    const raw = extractBlocks(String(p.post_content));
    const kind = classify(raw);
    const rewrite = makeRewriter(url);
    const blocks: PageBlock[] = [];

    if (kind === "content") {
      const cleaned = await cleanHtml(String(p.post_content), { media, usedBy: url, rewriteLink: rewrite });
      if (cleaned.text) blocks.push({ kind: "html", html: cleaned.html, toc: cleaned.toc });
    } else {
      for (const b of raw) await pushBlock(blocks, b, { media, url, rewrite, articles, catSlugSet, faqGroups });
    }
    const text = blocks.map((b) => ("text" in b ? b.text : "html" in b ? cheerio.load(b.html).root().text() : "")).join(" ").replace(/\s+/g, " ").trim();
    exportedPages.push({
      id,
      slug: String(p.post_name),
      url,
      title: decode(String(p.post_title)),
      kind,
      parentUrl: null,
      excerpt: excerpt(text),
      blocks,
      updatedAt: iso(p.post_modified_gmt),
      text,
    });
  }
  // Parent = the hub page that links to this page (the builder "tree").
  for (const page of exportedPages) {
    const parent = exportedPages.find((o) => o !== page && o.blocks.some((b) => b.kind === "links" && b.items.some((i) => i.href === page.url)));
    page.parentUrl = parent?.url ?? null;
    for (const b of page.blocks) if (b.kind === "links") for (const i of b.items) inbound.set(i.href, (inbound.get(i.href) ?? 0) + 1);
  }
  for (const a of articles) a.inboundLinks = inbound.get(a.url) ?? 0;

  /* ---------------- navigation ---------------- */
  const menu = await q(
    `SELECT p.ID, p.post_title, p.menu_order,
            MAX(CASE WHEN m.meta_key='_menu_item_type' THEN m.meta_value END) AS type,
            MAX(CASE WHEN m.meta_key='_menu_item_object_id' THEN m.meta_value END) AS object_id,
            MAX(CASE WHEN m.meta_key='_menu_item_url' THEN m.meta_value END) AS url
       FROM ${T("posts")} p JOIN ${T("postmeta")} m ON m.post_id = p.ID
      WHERE p.post_type='nav_menu_item' AND p.post_status='publish'
      GROUP BY p.ID ORDER BY p.menu_order`,
  );
  const navigation: NavItem[] = menu
    .map((m): NavItem | null => {
      const objectId = Number(m.object_id);
      if (m.type === "post_type") {
        if (objectId === frontPageId) return { label: String(m.post_title) || "Home", href: "/" };
        const pg = exportedPages.find((x) => x.id === objectId);
        const art = articles.find((x) => x.id === objectId);
        const target = pg ?? art;
        return target ? { label: String(m.post_title) || target.title, href: target.url } : null;
      }
      return null; // custom links: only "#fusion-search", replaced by the search dialog
    })
    .filter((x): x is NavItem => !!x);

  /* ---------------- redirects ---------------- */
  const redirects: Redirect[] = [];
  for (const [slug, to] of Object.entries(REPLACED_PAGES)) redirects.push({ from: `/${slug}/`, to, status: 301, reason: "Page replaced by new application" });
  for (const [from, to] of Object.entries(LEGACY_ALIASES)) redirects.push({ from, to, status: 301, reason: "Old page slug" });
  for (const p of posts) redirects.push({ from: datedUrl(p), to: articleUrl.get(Number(p.ID))!, status: 301, reason: "Old date-based permalink" });
  for (const a of articles) if (a.url !== a.legacyUrl) redirects.push({ from: `/?p=${a.id}`, to: a.url, status: 301, reason: "Slug collided with a page; article moved" });
  for (const c of categories) {
    if (c.path.length > 1) redirects.push({ from: `/category/${c.slug}/`, to: c.url, status: 301, reason: "Short category URL (WordPress redirected these too)" });
  }
  for (const c of categories.filter((c) => c.articleCount === 0)) {
    const target = nearestNonEmpty(c, categories);
    redirects.push({ from: c.url, to: target, status: 301, reason: "Category has no articles" });
  }
  redirects.push({ from: "/category/uncategorized/", to: "/", status: 301, reason: "Default WordPress category" });
  for (const f of faqs) redirects.push({ from: `/faq-items/${f.slug}/`, to: `/faq/#${f.slug}`, status: 301, reason: "Individual FAQ page -> FAQ section" });
  for (const r of postRows.filter((r) => EXCLUDED_POST_IDS.has(Number(r.ID)))) redirects.push({ from: `/${r.post_name}/`, to: null, status: 410, reason: "Attacker-created post" });
  for (const from of ["/feed/", "/comments/feed/", "/wp-login.php", "/wp-admin/", "/xmlrpc.php", "/wp-json/", "/author/ppadmin/", "/author/cgoswami/"]) {
    redirects.push({ from, to: from.startsWith("/author") ? "/" : null, status: from.startsWith("/author") ? 301 : 410, reason: "WordPress endpoint no longer exists" });
  }

  /* ---------------- write ---------------- */
  site.faqGroups = faqGroups.map((g) => ({ slug: String(g.slug), name: decode(String(g.name)) }));
  fs.mkdirSync(CONTENT_DIR, { recursive: true });
  const write = (name: string, data: unknown) => fs.writeFileSync(path.join(CONTENT_DIR, name), JSON.stringify(data, null, 1) + "\n");
  write("site.json", site);
  write("categories.json", categories);
  write("tags.json", tags);
  write("articles.json", articles);
  write("faqs.json", faqs);
  write("pages.json", exportedPages);
  write("navigation.json", navigation);
  write("redirects.json", redirects);

  writeReport(report, media, { articles, exportedPages, faqs, categories });
  await db.end();
  console.log(`Done: ${articles.length} articles, ${exportedPages.length} pages, ${faqs.length} FAQs, ${categories.length} categories.`);
  console.log(`Media: ${media.missing.size} referenced images not found in uploads (see migration-report/missing-media.md).`);
}

/* ---------------- helpers ---------------- */

type BlockCtx = {
  media: MediaLibrary;
  url: string;
  rewrite: (h: string) => string;
  articles: Article[];
  catSlugSet: (s: string[]) => Set<number>;
  faqGroups: Row[];
};

async function pushBlock(blocks: PageBlock[], b: RawBlock, ctx: BlockCtx) {
  const last = blocks[blocks.length - 1];
  switch (b.kind) {
    case "heading":
      blocks.push({ kind: "heading", text: b.text });
      break;
    case "text": {
      const html = sanitize(b.html.replace(/\r?\n/g, " "));
      if (html) blocks.push({ kind: "text", html });
      break;
    }
    case "link": {
      const image: MediaAsset | null = b.image ? await ctx.media.resolve(b.image, ctx.url) : null;
      const item = { label: b.label || "Open", href: ctx.rewrite(b.href), image };
      if (last?.kind === "links") last.items.push(item);
      else blocks.push({ kind: "links", items: [item] });
      break;
    }
    case "video": {
      const item = { id: slugify(b.title) || `video-${Date.now()}`, title: b.title, src: b.src };
      if (last?.kind === "videos") {
        let id = item.id;
        for (let i = 2; last.items.some((v) => v.id === id); i++) id = `${item.id}-${i}`;
        last.items.push({ ...item, id });
      } else blocks.push({ kind: "videos", items: [item] });
      break;
    }
    case "listing": {
      const include = b.includeCategories.length ? ctx.catSlugSet(b.includeCategories) : null;
      const exclude = ctx.catSlugSet(b.excludeCategories);
      const ids = ctx.articles
        .filter((a) => (!include || a.categoryIds.some((c) => include.has(c))) && !a.categoryIds.some((c) => exclude.has(c)))
        .map((a) => a.id);
      blocks.push({ kind: "articles", articleIds: ids });
      break;
    }
    case "faq":
      for (const slug of b.categories) {
        const g = ctx.faqGroups.find((x) => x.slug === slug);
        const title = last?.kind === "heading" ? (blocks.pop() as { text: string }).text : decode(String(g?.name ?? slug));
        blocks.push({ kind: "faq", group: slug, title });
      }
      break;
  }
}

async function featuredImage(q: (s: string, p?: unknown[]) => Promise<Row[]>, media: MediaLibrary, postId: number, usedBy: string) {
  const rows = await q(
    `SELECT a.meta_value AS file FROM ${T("postmeta")} t JOIN ${T("postmeta")} a ON a.post_id = t.meta_value AND a.meta_key='_wp_attached_file'
      WHERE t.post_id=? AND t.meta_key='_thumbnail_id' LIMIT 1`,
    [postId],
  );
  if (!rows[0]?.file) return null;
  return media.resolve(`/wp-content/uploads/${rows[0].file}`, `${usedBy} (featured image)`);
}

function excerpt(text: string, max = 158): string {
  const clean = text.replace(/<[^>]+>/g, " ").replace(/\s+/g, " ").replace(/^(introduction|overview|purpose)\s*[:\-]?\s*/i, "").trim();
  if (clean.length <= max) return clean;
  return clean.slice(0, clean.lastIndexOf(" ", max)).replace(/[,;:.\s]+$/, "") + "…";
}

function nearestNonEmpty(c: Category, all: Category[]): string {
  let cur: Category | undefined = c;
  while (cur) {
    if (cur.articleCount > 0) return cur.url;
    cur = all.find((x) => x.id === cur!.parentId);
  }
  return "/";
}

function writeReport(report: { excluded: string[]; reviewNeeded: string[]; brokenLinks: Map<string, Set<string>>; warnings: string[] }, media: MediaLibrary, data: { articles: Article[]; exportedPages: Page[]; faqs: Faq[]; categories: Category[] }) {
  fs.mkdirSync(REPORT_DIR, { recursive: true });
  const missing = [...media.missing.entries()].sort(([a], [b]) => a.localeCompare(b));
  fs.writeFileSync(
    path.join(REPORT_DIR, "missing-media.md"),
    `# Missing media\n\nThese images are referenced by content but were not found in \`WP_UPLOADS_DIR\`. Readers see a labelled "Screenshot unavailable" placeholder instead.\nRestore the files from a clean (pre-August-2026) backup into the same paths and re-run \`npm run export:content\`.\n\n| File (under wp-content/uploads) | Used on |\n|---|---|\n` +
      missing.map(([file, used]) => `| \`${file}\` | ${[...used].slice(0, 4).join(", ")}${used.size > 4 ? ` +${used.size - 4}` : ""} |`).join("\n") + "\n",
  );
  fs.writeFileSync(
    path.join(REPORT_DIR, "summary.md"),
    [
      `# Export summary (${new Date().toISOString()})`,
      ``,
      `- Articles: ${data.articles.length}`,
      `- Pages: ${data.exportedPages.length} (${Object.entries(countBy(data.exportedPages.map((p) => p.kind))).map(([k, v]) => `${v} ${k}`).join(", ")})`,
      `- FAQs: ${data.faqs.length}`,
      `- Categories with articles: ${data.categories.filter((c) => c.articleCount).length} of ${data.categories.length}`,
      `- Missing images: ${media.missing.size}`,
      ``,
      `## Excluded content`,
      ...report.excluded.map((e) => `- ${e}`),
      ``,
      `## Modified after compromise start (review before publishing)`,
      ...(report.reviewNeeded.length ? report.reviewNeeded.map((e) => `- ${e}`) : ["- None"]),
      ``,
      `## Internal links with no destination`,
      ...([...report.brokenLinks.entries()].map(([k, v]) => `- \`${k}\` linked from ${[...v].join(", ")}`) || []),
      ...(report.brokenLinks.size ? [] : ["- None"]),
      "",
    ].join("\n"),
  );
}

const countBy = (xs: string[]) => xs.reduce<Record<string, number>>((acc, x) => ((acc[x] = (acc[x] ?? 0) + 1), acc), {});

function loadEnvFile(file: string) {
  if (!fs.existsSync(file)) return;
  for (const line of fs.readFileSync(file, "utf8").split(/\r?\n/)) {
    const m = line.match(/^\s*([A-Z0-9_]+)\s*=\s*(.*)\s*$/);
    if (m && process.env[m[1]] === undefined) process.env[m[1]] = m[2].replace(/^(['"])(.*)\1$/, "$2");
  }
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
