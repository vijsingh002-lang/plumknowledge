/**
 * Content that must never be migrated.
 *
 * Posts 3026, 3032, 3038, 3044, 3053, 3063 (all titled "x") were created
 * between 2026-08-01 and 2026-08-03 through the "wp2shell" backdoor
 * plugins found in wp-content/plugins. They are exploit test posts, not
 * knowledge-base content.
 */
export const EXCLUDED_POST_IDS = new Set([3026, 3032, 3038, 3044, 3053, 3063]);

/** Pages that are replaced by the new application rather than migrated. */
export const REPLACED_PAGES: Record<string, string> = {
  home: "/", // WordPress front page -> new homepage
  "mdtf-results-page": "/search/", // MDTF filter plugin results page -> new search
};

/** Categories that exist only as WordPress defaults. */
export const EXCLUDED_CATEGORY_SLUGS = new Set(["uncategorized"]);

/**
 * First known malicious activity. Any published content modified on or after
 * this date is reported for manual review before it goes live.
 */
export const COMPROMISE_START = new Date("2026-08-01T00:00:00Z");

/**
 * Legacy URLs found in content links that no longer exist in WordPress.
 * "/different-types-of-ordering/" was the original slug of page 1456
 * (now "Plum POS Guide"), confirmed by that page's revision history.
 */
export const LEGACY_ALIASES: Record<string, string> = {
  "/different-types-of-ordering/": "/plum-pos-guide/",
};
