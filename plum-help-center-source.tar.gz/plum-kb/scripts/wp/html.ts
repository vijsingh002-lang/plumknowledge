import * as cheerio from "cheerio";
import type { AnyNode, Element } from "domhandler";
import sanitizeHtml from "sanitize-html";
import { parseShortcodes, nodeText, type ShortcodeNode } from "./shortcodes";
import { wpautop } from "./wpautop";
import type { MediaLibrary } from "./media";

export type TocEntry = { id: string; text: string; level: 2 | 3 };

export type CleanContext = {
  media: MediaLibrary;
  usedBy: string;
  /** Rewrites a link found in content; returns the new href. */
  rewriteLink: (href: string) => string;
};

export const ALLOWED_VIDEO_HOSTS = ["altametricslist.com"];
const ALLOWED_IFRAME = /^https:\/\/(www\.youtube(-nocookie)?\.com\/embed\/|player\.vimeo\.com\/video\/)/;

/* ------------------------------------------------------------------ */
/* 1. Shortcodes -> HTML                                               */
/* ------------------------------------------------------------------ */

const esc = (s: string) => s.replace(/&/g, "&amp;").replace(/"/g, "&quot;").replace(/</g, "&lt;");

export function shortcodesToHtml(nodes: ShortcodeNode[]): string {
  return nodes
    .map((n) => {
      if (n.type === "text") return n.value;
      const inner = () => shortcodesToHtml(n.children);
      const a = n.attrs;
      switch (n.name) {
        case "fusion_title":
          return `\n\n<h2>${nodeText(n.children).replace(/<[^>]+>/g, "").trim()}</h2>\n\n`;
        case "fusion_imageframe": {
          const src = nodeText(n.children).trim();
          if (!/^https?:\/\/|^\//.test(src)) return inner();
          const img = `<img src="${esc(src)}" alt="${esc(a.alt ?? "")}">`;
          return `\n\n${a.link ? `<a href="${esc(a.link)}">${img}</a>` : img}\n\n`;
        }
        case "fusion_button":
          return a.link ? `\n\n<p><a href="${esc(a.link.trim())}">${inner().trim()}</a></p>\n\n` : inner();
        case "fusion_separator":
        case "fusion_widget":
        case "fusion_blog":
        case "fusion_faq":
          return "";
        case "fusion_tab":
        case "fusion_toggle":
          return `\n\n<h3>${esc(a.title ?? "")}</h3>\n\n${inner()}`;
        case "fusion_video":
        case "video": {
          const src = a.video || a.mp4 || a.src || "";
          return isAllowedVideo(src) ? `\n\n<video src="${esc(src)}"></video>\n\n` : "";
        }
        case "fusion_youtube":
          return a.id ? `\n\n<iframe src="https://www.youtube-nocookie.com/embed/${esc(a.id)}" title="${esc(a.title ?? "Video")}"></iframe>\n\n` : "";
        case "caption": {
          const html = inner();
          const imgMatch = html.match(/(<a[^>]*>)?\s*<img[^>]*>\s*(<\/a>)?/i);
          const caption = html.replace(imgMatch?.[0] ?? "", "").trim();
          return `\n\n<figure>${imgMatch?.[0] ?? ""}${caption ? `<figcaption>${caption}</figcaption>` : ""}</figure>\n\n`;
        }
        case "embed": {
          const url = nodeText(n.children).trim();
          const yt = url.match(/(?:youtube\.com\/watch\?v=|youtu\.be\/)([\w-]{11})/);
          return yt ? `\n\n<iframe src="https://www.youtube-nocookie.com/embed/${yt[1]}" title="Video"></iframe>\n\n` : `<a href="${esc(url)}">${esc(url)}</a>`;
        }
        default:
          return inner(); // layout wrappers: container / row / column / text / tabs
      }
    })
    .join("");
}

export function isAllowedVideo(src: string): boolean {
  try {
    const u = new URL(src);
    return u.protocol === "https:" && ALLOWED_VIDEO_HOSTS.includes(u.hostname) && /\.(mp4|webm)$/i.test(u.pathname);
  } catch {
    return false;
  }
}

/* ------------------------------------------------------------------ */
/* 2. Structural cleanup (Google-Sites / Avada markup -> clean HTML)    */
/* ------------------------------------------------------------------ */

const BLOCK_TAGS = new Set(["p", "div", "section", "article", "ul", "ol", "li", "table", "figure", "blockquote", "h1", "h2", "h3", "h4", "h5", "h6", "pre", "video", "iframe", "hr", "aside", "dl"]);

export function slugify(text: string): string {
  return text
    .toLowerCase()
    .normalize("NFKD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/&[a-z]+;/g, "")
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "")
    .slice(0, 80);
}

export async function cleanHtml(raw: string, ctx: CleanContext): Promise<{ html: string; toc: TocEntry[]; text: string }> {
  const withoutShortcodes = shortcodesToHtml(parseShortcodes(raw.replace(/\u00a0/g, " ")));
  const $ = cheerio.load(wpautop(withoutShortcodes), null, false);

  // Drop layout noise.
  $("script, style, noscript, form, input, button, object, embed, link, meta").remove();
  $("iframe").each((_, el) => {
    if (!ALLOWED_IFRAME.test($(el).attr("src") ?? "")) $(el).remove();
  });
  $("span, font, section, article, header, footer, main, center, u").each((_, el) => {
    $(el).replaceWith($(el).contents());
  });

  // Google-Sites exports wrap everything in div soup. Deepest first:
  // a div with block children is unwrapped, a div with inline content becomes <p>.
  const divs = $("div").toArray().reverse();
  for (const el of divs) {
    const $el = $(el);
    const hasBlock = $el.children().toArray().some((c) => BLOCK_TAGS.has((c as Element).tagName));
    if (hasBlock || !$el.text().trim() && !$el.find("img,video,iframe").length) $el.replaceWith($el.contents());
    else el.tagName = "p";
  }

  // Paragraphs that only hold a block (e.g. <p><img></p> is fine, <p><ul> is not).
  $("p").each((_, el) => {
    const $el = $(el);
    if ($el.children("ul,ol,table,h1,h2,h3,h4,h5,h6,figure,video,iframe,p").length) $el.replaceWith($el.contents());
  });

  // Headings: article H1 is the title, so the content's top level becomes H2.
  const levels = $("h1,h2,h3,h4,h5,h6").toArray().map((h) => Number((h as Element).tagName[1]));
  if (levels.length) {
    const shift = Math.min(...levels) - 2;
    $("h1,h2,h3,h4,h5,h6").each((_, el) => {
      const lvl = Math.min(4, Math.max(2, Number(el.tagName[1]) - shift));
      el.tagName = `h${lvl}`;
    });
  }
  // A heading made of nothing but bold text: strip redundant <strong>.
  $("h2 strong, h3 strong, h4 strong").each((_, el) => {
    $(el).replaceWith($(el).contents());
  });
  $("h2,h3,h4").each((_, el) => {
    if (!$(el).text().trim()) $(el).remove();
  });

  // Content pasted from Google Sites uses bold paragraphs as headings. Only when an
  // article has no real structure, promote short bold-only paragraphs to H2.
  if ($("h2,h3").length < 2) {
    $("p").each((_, el) => {
      const $p = $(el);
      const only = $p.children("strong,b");
      const text = $p.text().trim();
      if (only.length === 1 && only.text().trim() === text && text.length >= 3 && text.length <= 60 && !/[:.,]$/.test(text) && !/^step\s*\d/i.test(text)) {
        el.tagName = "h2";
        $p.html(text);
      }
    });
  }

  // Media
  for (const el of $("img").toArray()) {
    const $img = $(el);
    const src = $img.attr("src") ?? "";
    const alt = ($img.attr("alt") ?? "").trim();
    const asset = await ctx.media.resolve(src, ctx.usedBy);
    if (asset) {
      $img.attr({ src: asset.src, srcset: asset.srcSet, sizes: "(min-width: 1024px) 720px, 100vw", width: String(asset.width), height: String(asset.height), loading: "lazy", decoding: "async", alt });
      const $parentLink = $img.parent("a");
      if ($parentLink.length && /\/wp-content\/uploads\//.test($parentLink.attr("href") ?? "")) $parentLink.attr("href", asset.src);
    } else {
      const label = alt || humanFileName(src);
      $img.replaceWith(`<span class="media-missing" role="img" aria-label="${label ? `Image unavailable: ${esc(label)}` : "Image unavailable"}">Screenshot unavailable${label ? `: ${esc(label)}` : ""}</span>`);
    }
  }
  $("video").each((_, el) => {
    $(el).attr({ controls: "", preload: "metadata", playsinline: "" });
  });

  // Links
  $("a").each((_, el) => {
    const $a = $(el);
    const href = ($a.attr("href") ?? "").trim();
    if (!href || /^(javascript|data|vbscript):/i.test(href)) {
      $a.replaceWith($a.contents());
      return;
    }
    const next = ctx.rewriteLink(href);
    $a.attr("href", next);
    if (/^https?:\/\//.test(next)) $a.attr({ target: "_blank", rel: "noopener noreferrer nofollow" });
  });

  // Callouts and step markers — purely presentational, derived from the author's own words.
  $("p").each((_, el) => {
    const $p = $(el);
    const text = $p.text().trim();
    const callout = text.match(/^(note|important|warning|caution|tip|please note)\s*[:\-–]/i);
    if (callout) {
      const kind = /warning|caution|important/i.test(callout[1]) ? "warning" : /tip/i.test(callout[1]) ? "tip" : "info";
      $p.wrap(`<aside class="callout callout-${kind}"></aside>`);
      return;
    }
    if (/^step\s*\d+\s*[:.\-–]/i.test(text)) $p.addClass("step");
  });

  // Empty paragraphs and trailing breaks.
  $("p").each((_, el) => {
    const $p = $(el);
    if (!$p.text().trim() && !$p.find("img,video,iframe,.media-missing").length) $p.remove();
  });
  $("br").each((_, el) => {
    const next = el.next as AnyNode | null;
    if (!next || (next.type === "tag" && ((next as Element).tagName === "br" || BLOCK_TAGS.has((next as Element).tagName)))) $(el).remove();
  });

  $("table").each((_, el) => {
    $(el).wrap('<div class="table-wrap" tabindex="0" role="region" aria-label="Table"></div>');
  });

  // Heading anchors + table of contents.
  const toc: TocEntry[] = [];
  const used = new Set<string>();
  $("h2,h3").each((_, el) => {
    const text = $(el).text().replace(/\s+/g, " ").trim();
    let id = slugify(text) || "section";
    for (let i = 2; used.has(id); i++) id = `${slugify(text)}-${i}`;
    used.add(id);
    $(el).attr("id", id);
    toc.push({ id, text, level: el.tagName === "h2" ? 2 : 3 });
  });

  const html = sanitize($.html());
  const text = cheerio.load(html).root().text().replace(/Screenshot unavailable(: [^\n]*)?/g, " ").replace(/\s+/g, " ").trim();
  return { html, toc, text };
}

function humanFileName(src: string): string {
  if (!/\/wp-content\/uploads\//.test(src)) return "";
  const file = src.split("/").pop()?.replace(/\.[a-z0-9]+$/i, "").replace(/-\d+x\d+$/, "") ?? "";
  if (file.length > 40 || /^[0-9_\- ]+$/.test(file) || /image|screenshot|chatgpt|^\d{6,}/i.test(file)) return "";
  return file.replace(/[_-]+/g, " ").replace(/\s+\d+$/, (m) => ` (${m.trim()})`).trim();
}

/* ------------------------------------------------------------------ */
/* 3. Final allowlist sanitization — nothing outside this list survives */
/* ------------------------------------------------------------------ */

export function sanitize(html: string): string {
  return sanitizeHtml(html, {
    allowedTags: ["h2", "h3", "h4", "p", "br", "hr", "strong", "b", "em", "i", "s", "sub", "sup", "mark", "small", "code", "pre", "kbd", "blockquote", "ul", "ol", "li", "dl", "dt", "dd", "a", "img", "figure", "figcaption", "table", "thead", "tbody", "tfoot", "tr", "th", "td", "caption", "colgroup", "col", "div", "span", "aside", "video", "iframe"],
    allowedAttributes: {
      a: ["href", "target", "rel"],
      img: ["src", "srcset", "sizes", "alt", "width", "height", "loading", "decoding"],
      video: ["src", "controls", "preload", "playsinline"],
      iframe: ["src", "title", "allow", "allowfullscreen", "loading"],
      th: ["colspan", "rowspan", "scope"],
      td: ["colspan", "rowspan"],
      ol: ["start", "type"],
      h2: ["id"],
      h3: ["id"],
      div: ["tabindex", "role", "aria-label"],
      span: ["role", "aria-label"],
    },
    allowedClasses: {
      aside: ["callout", "callout-info", "callout-warning", "callout-tip"],
      p: ["step"],
      div: ["table-wrap"],
      span: ["media-missing"],
    },
    allowedSchemes: ["https", "http", "mailto", "tel"],
    allowedSchemesByTag: { img: ["https"], video: ["https"], iframe: ["https"] },
    allowProtocolRelative: false,
    allowedIframeHostnames: ["www.youtube-nocookie.com", "www.youtube.com", "player.vimeo.com"],
    transformTags: {
      b: "strong",
      i: "em",
      iframe: (tagName, attribs) => ({ tagName, attribs: { ...attribs, loading: "lazy", allowfullscreen: "", allow: "encrypted-media; picture-in-picture" } }),
    },
    exclusiveFilter: (frame) => frame.tag === "video" && !isAllowedVideo(frame.attribs.src ?? ""),
  })
    .replace(/\n{2,}/g, "\n")
    .replace(/<p>\s+/g, "<p>")
    .replace(/\s+<\/(p|li|h2|h3|h4)>/g, "</$1>")
    .trim();
}
