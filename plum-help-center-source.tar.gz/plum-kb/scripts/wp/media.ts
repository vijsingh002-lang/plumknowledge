import fs from "node:fs";
import path from "node:path";
import sharp from "sharp";

/**
 * Every image is decoded and re-encoded with sharp rather than copied.
 * That (1) proves the file is a real image, (2) strips metadata and any
 * appended payload (polyglot files are a common webshell trick), and
 * (3) produces responsive WebP renditions, since static export has no
 * runtime image optimizer.
 */

export type MediaAsset = {
  src: string;
  srcSet: string;
  width: number;
  height: number;
};

const WIDTHS = [640, 1280, 1920];
const ALLOWED_EXT = /\.(png|jpe?g|webp|gif|avif)$/i;

export class MediaLibrary {
  private cache = new Map<string, MediaAsset | null>();
  readonly missing = new Map<string, Set<string>>(); // uploads path -> pages using it

  constructor(
    private uploadsDir: string,
    private outDir: string,
    private publicPrefix = "/media",
  ) {}

  /** Map any WordPress upload URL (absolute, relative, resized) to an uploads-relative path. */
  static toUploadsPath(url: string): string | null {
    const m = url.match(/\/wp-content\/uploads\/([^?#"'\s]+)/i);
    if (!m) return null;
    return decodeURIComponent(m[1]).replace(/\[\/?fusion_[a-z_]+$/i, "");
  }

  private candidates(rel: string): string[] {
    const out = [rel];
    const unsized = rel.replace(/-\d+x\d+(\.[a-z0-9]+)$/i, "$1");
    if (unsized !== rel) out.push(unsized);
    const unscaled = unsized.replace(/-scaled(\.[a-z0-9]+)$/i, "$1");
    if (unscaled !== unsized) out.push(unscaled);
    return out;
  }

  async resolve(url: string, usedBy: string): Promise<MediaAsset | null> {
    const rel = MediaLibrary.toUploadsPath(url);
    if (!rel) {
      // Hotlinked third-party images (e.g. expiring Google Docs renders) are not
      // imported: they would need a third-party img-src in the CSP.
      if (/^https?:\/\//.test(url)) this.noteMissing(`[external] ${url.slice(0, 90)}`, usedBy);
      return null;
    }
    if (!ALLOWED_EXT.test(rel) || rel.includes("..")) return null;
    if (this.cache.has(rel)) {
      const hit = this.cache.get(rel) ?? null;
      if (!hit) this.noteMissing(rel, usedBy);
      return hit;
    }

    let asset: MediaAsset | null = null;
    for (const candidate of this.candidates(rel)) {
      const file = path.join(this.uploadsDir, candidate);
      if (!file.startsWith(this.uploadsDir) || !fs.existsSync(file)) continue;
      asset = await this.process(file, candidate).catch((err) => {
        console.warn(`  ! rejected ${candidate}: ${(err as Error).message}`);
        return null;
      });
      if (asset) break;
    }
    this.cache.set(rel, asset);
    if (!asset) this.noteMissing(rel, usedBy);
    return asset;
  }

  private noteMissing(rel: string, usedBy: string) {
    if (!this.missing.has(rel)) this.missing.set(rel, new Set());
    this.missing.get(rel)!.add(usedBy);
  }

  private async process(file: string, rel: string): Promise<MediaAsset> {
    const meta = await sharp(file, { failOn: "error" }).metadata();
    if (!meta.width || !meta.height) throw new Error("not a decodable image");

    const base = rel.replace(ALLOWED_EXT, "").replace(/[^a-zA-Z0-9/_-]/g, "-");
    const widths = WIDTHS.filter((w) => w < meta.width!).concat(Math.min(meta.width, 2400));
    const unique = [...new Set(widths)];
    const entries: string[] = [];

    for (const w of unique) {
      const outRel = `${base}-${w}.webp`;
      const outFile = path.join(this.outDir, outRel);
      fs.mkdirSync(path.dirname(outFile), { recursive: true });
      if (!fs.existsSync(outFile)) {
        await sharp(file).rotate().resize({ width: w, withoutEnlargement: true }).webp({ quality: 80 }).toFile(outFile);
      }
      entries.push(`${this.publicPrefix}/${outRel} ${w}w`);
    }
    const largest = entries[entries.length - 1].split(" ")[0];
    const width = Math.min(meta.width, 2400);
    return {
      src: largest,
      srcSet: entries.join(", "),
      width,
      height: Math.round((meta.height * width) / meta.width),
    };
  }
}
