import { parseShortcodes, nodeText, type ShortcodeNode } from "./shortcodes";
import { isAllowedVideo } from "./html";

/**
 * The site's navigation pages were assembled in Avada's page builder:
 * image + button grids (hubs), tabbed MP4 libraries (training videos),
 * post-grid widgets (article listings) and FAQ widgets. Rendering that
 * builder markup would drag Avada's layout into the new site, so each
 * page is reduced to the structure it actually expresses.
 */

export type RawBlock =
  | { kind: "heading"; text: string }
  | { kind: "text"; html: string }
  | { kind: "link"; label: string; href: string; image?: string }
  | { kind: "video"; title: string; src: string }
  | { kind: "listing"; includeCategories: string[]; excludeCategories: string[]; limit: number }
  | { kind: "faq"; categories: string[] };

type SC = Extract<ShortcodeNode, { type: "shortcode" }>;
const strip = (s: string) => s.replace(/<[^>]+>/g, " ").replace(/&nbsp;/g, " ").replace(/\s+/g, " ").trim();
const list = (s?: string) => (s ?? "").split(",").map((x) => x.trim()).filter(Boolean);

export function extractBlocks(content: string): RawBlock[] {
  const blocks: RawBlock[] = [];
  let pendingImage: string | undefined;
  let pendingTitle: string | undefined;

  const visit = (nodes: ShortcodeNode[]) => {
    for (const n of nodes) {
      if (n.type === "text") continue;
      const sc = n as SC;
      switch (sc.name) {
        case "fusion_title": {
          const text = strip(nodeText(sc.children));
          if (text) blocks.push({ kind: "heading", text });
          break;
        }
        case "fusion_text": {
          const html = nodeText(sc.children).trim();
          if (strip(html)) blocks.push({ kind: "text", html });
          break;
        }
        case "fusion_imageframe":
          pendingImage = nodeText(sc.children).trim() || undefined;
          if (sc.attrs.link) {
            blocks.push({ kind: "link", label: sc.attrs.alt || "", href: sc.attrs.link.trim(), image: pendingImage });
            pendingImage = undefined;
          }
          break;
        case "fusion_button": {
          const label = strip(nodeText(sc.children));
          if (sc.attrs.link) blocks.push({ kind: "link", label, href: sc.attrs.link.trim(), image: pendingImage });
          pendingImage = undefined;
          break;
        }
        case "fusion_tab":
        case "fusion_toggle":
          pendingTitle = sc.attrs.title?.trim();
          visit(sc.children);
          break;
        case "fusion_video": {
          const src = sc.attrs.video ?? "";
          if (isAllowedVideo(src)) blocks.push({ kind: "video", title: pendingTitle || lastHeading(blocks) || "Training video", src });
          pendingTitle = undefined;
          break;
        }
        case "fusion_blog":
          blocks.push({ kind: "listing", includeCategories: list(sc.attrs.cat_slug), excludeCategories: list(sc.attrs.exclude_cats), limit: Number(sc.attrs.number_posts) || -1 });
          break;
        case "fusion_faq":
          blocks.push({ kind: "faq", categories: list(sc.attrs.cats_slug) });
          break;
        default:
          visit(sc.children);
      }
    }
  };
  visit(parseShortcodes(content));
  return blocks;
}

function lastHeading(blocks: RawBlock[]): string | undefined {
  for (let i = blocks.length - 1; i >= 0; i--) {
    const b = blocks[i];
    if (b.kind === "heading") return b.text;
  }
}

export function classify(blocks: RawBlock[]): "videos" | "hub" | "listing" | "faq" | "content" {
  const count = (k: RawBlock["kind"]) => blocks.filter((b) => b.kind === k).length;
  if (count("faq")) return "faq";
  if (count("video")) return "videos";
  if (count("listing")) return "listing";
  if (count("link") >= 2) return "hub";
  return "content";
}
