/**
 * Minimal, dependency-free parser for the WordPress/Avada shortcodes found in
 * this site's content. Only real shortcode names are parsed (fusion_*, caption,
 * embed, video). Bracketed words that authors typed as plain text, such as
 * "click Accept [button]" or "open the [tab]", are left untouched on purpose.
 */

export type ShortcodeNode =
  | { type: "text"; value: string }
  | { type: "shortcode"; name: string; attrs: Record<string, string>; children: ShortcodeNode[] };

const TOKEN = /\[(\/)?(fusion_[a-z0-9_]+|caption|embed|video)(\s[^\]]*)?\]/g;

// Fusion elements that never have a closing tag.
const SELF_CLOSING = new Set(["fusion_separator", "fusion_blog", "fusion_faq", "fusion_video", "fusion_youtube", "fusion_vimeo", "fusion_widget", "video"]);

export function parseAttrs(raw = ""): Record<string, string> {
  const attrs: Record<string, string> = {};
  const re = /([\w-]+)\s*=\s*(?:"([^"]*)"|'([^']*)'|(\S+))/g;
  let m: RegExpExecArray | null;
  while ((m = re.exec(raw))) attrs[m[1]] = (m[2] ?? m[3] ?? m[4] ?? "").trim();
  return attrs;
}

export function parseShortcodes(input: string): ShortcodeNode[] {
  const root: ShortcodeNode = { type: "shortcode", name: "#root", attrs: {}, children: [] };
  const stack: Extract<ShortcodeNode, { type: "shortcode" }>[] = [root as never];
  let last = 0;
  let m: RegExpExecArray | null;
  TOKEN.lastIndex = 0;

  const top = () => stack[stack.length - 1];
  const pushText = (value: string) => value && top().children.push({ type: "text", value });

  while ((m = TOKEN.exec(input))) {
    pushText(input.slice(last, m.index));
    last = TOKEN.lastIndex;
    const [, closing, name, rawAttrs] = m;

    if (closing) {
      // Close the nearest matching open element; tolerate malformed nesting.
      const idx = stack.map((n) => n.name).lastIndexOf(name);
      if (idx > 0) stack.length = idx;
      continue;
    }
    const node = { type: "shortcode" as const, name, attrs: parseAttrs(rawAttrs), children: [] as ShortcodeNode[] };
    top().children.push(node);
    if (!SELF_CLOSING.has(name) || hasClosingTag(input, name, last)) stack.push(node);
  }
  pushText(input.slice(last));
  return (root as Extract<ShortcodeNode, { type: "shortcode" }>).children;
}

function hasClosingTag(input: string, name: string, from: number): boolean {
  const close = input.indexOf(`[/${name}]`, from);
  if (close === -1) return false;
  const nextOpen = input.indexOf(`[${name} `, from);
  return nextOpen === -1 || close < nextOpen;
}

export function nodeText(nodes: ShortcodeNode[]): string {
  return nodes.map((n) => (n.type === "text" ? n.value : nodeText(n.children))).join("");
}

export function walk(nodes: ShortcodeNode[], visit: (n: Extract<ShortcodeNode, { type: "shortcode" }>) => void) {
  for (const n of nodes) {
    if (n.type === "shortcode") {
      visit(n);
      walk(n.children, visit);
    }
  }
}
