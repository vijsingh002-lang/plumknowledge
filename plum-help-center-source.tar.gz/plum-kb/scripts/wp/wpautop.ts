/**
 * TypeScript port of WordPress core's wpautop() (wp-includes/formatting.php).
 * Classic-editor content stores paragraphs as blank lines, not <p> tags;
 * WordPress adds the tags at render time. Without this, articles collapse
 * into one run-on block.
 */
const BLOCKS =
  "(?:table|thead|tfoot|caption|col|colgroup|tbody|tr|td|th|div|dl|dd|dt|ul|ol|li|pre|form|map|area|blockquote|address|math|style|p|h[1-6]|hr|fieldset|legend|section|article|aside|hgroup|header|footer|nav|figure|figcaption|details|menu|summary|video|audio|iframe|source|img)";

export function wpautop(input: string): string {
  let text = input.replace(/\r\n|\r/g, "\n");
  if (!text.trim()) return "";

  // Protect <pre> blocks.
  const pres: string[] = [];
  text = text.replace(/<pre[\s>][\s\S]*?<\/pre>/gi, (m) => {
    pres.push(m);
    return `<pre wp-pre-tag-${pres.length - 1}></pre>`;
  });

  // Newlines inside tags (multi-line attributes) must not become <br>.
  text = text.replace(/<[^>]+>/g, (tag) => tag.replace(/\n/g, " "));

  text += "\n";
  text = text.replace(/<br\s*\/?>\s*<br\s*\/?>/gi, "\n\n");
  text = text.replace(new RegExp(`(<${BLOCKS}[\\s/>])`, "gi"), "\n\n$1");
  text = text.replace(new RegExp(`(</${BLOCKS}>)`, "gi"), "$1\n\n");
  text = text.replace(/\n\n+/g, "\n\n");

  text = text
    .split(/\n\s*\n/)
    .filter((p) => p.trim())
    .map((p) => `<p>${p.trim()}</p>\n`)
    .join("");

  text = text.replace(/<p>\s*<\/p>/g, "");
  text = text.replace(/<p>([^<]+)<\/(div|address|form)>/gi, "<p>$1</p></$2>");
  text = text.replace(new RegExp(`<p>\\s*(</?${BLOCKS}[^>]*>)\\s*</p>`, "gi"), "$1");
  text = text.replace(/<p>(<li.+?)<\/p>/gi, "$1");
  text = text.replace(/<p><blockquote([^>]*)>/gi, "<blockquote$1><p>");
  text = text.replace(/<\/blockquote><\/p>/gi, "</p></blockquote>");
  text = text.replace(new RegExp(`<p>\\s*(</?${BLOCKS}[^>]*>)`, "gi"), "$1");
  text = text.replace(new RegExp(`(</?${BLOCKS}[^>]*>)\\s*</p>`, "gi"), "$1");

  // Remaining single newlines become <br />.
  text = text.replace(/(?<!<br \/>)\s*\n/g, "<br />\n");
  text = text.replace(new RegExp(`(</?${BLOCKS}[^>]*>)\\s*<br />`, "gi"), "$1");
  text = text.replace(/<br \/>(\s*<\/?(?:p|li|div|dl|dd|dt|th|pre|td|ul|ol)[^>]*>)/gi, "$1");
  text = text.replace(/\n<\/p>$/g, "</p>");

  text = text.replace(/<pre wp-pre-tag-(\d+)><\/pre>/g, (_, i) => pres[Number(i)]);
  return text;
}
