import { z } from "zod";

/**
 * Content contract between the WordPress exporter and the frontend.
 * The app validates content/*.json against these schemas at build time,
 * so a bad export fails the build instead of shipping a broken page.
 */

export const TocEntrySchema = z.object({ id: z.string(), text: z.string(), level: z.union([z.literal(2), z.literal(3)]) });

export const CategorySchema = z.object({
  id: z.number(),
  slug: z.string(),
  name: z.string(),
  description: z.string(),
  parentId: z.number().nullable(),
  path: z.array(z.string()),
  url: z.string(),
  articleCount: z.number(),
});

export const TagSchema = z.object({ id: z.number(), slug: z.string(), name: z.string(), url: z.string(), articleCount: z.number() });

export const ArticleSchema = z.object({
  id: z.number(),
  slug: z.string(),
  url: z.string(),
  legacyUrl: z.string(),
  title: z.string(),
  excerpt: z.string(),
  html: z.string(),
  text: z.string(),
  toc: z.array(TocEntrySchema),
  categoryIds: z.array(z.number()),
  primaryCategoryId: z.number().nullable(),
  tagIds: z.array(z.number()),
  author: z.string().nullable(),
  publishedAt: z.string(),
  updatedAt: z.string(),
  readingMinutes: z.number(),
  wordCount: z.number(),
  inboundLinks: z.number(),
  ogImage: z.string().nullable(),
});

export const FaqSchema = z.object({
  id: z.number(),
  slug: z.string(),
  question: z.string(),
  html: z.string(),
  text: z.string(),
  groups: z.array(z.string()),
  order: z.number(),
});

export const PageBlockSchema = z.discriminatedUnion("kind", [
  z.object({ kind: z.literal("heading"), text: z.string() }),
  z.object({ kind: z.literal("text"), html: z.string() }),
  z.object({
    kind: z.literal("links"),
    items: z.array(z.object({ label: z.string(), href: z.string(), image: z.object({ src: z.string(), srcSet: z.string(), width: z.number(), height: z.number() }).nullable() })),
  }),
  z.object({ kind: z.literal("videos"), items: z.array(z.object({ id: z.string(), title: z.string(), src: z.string() })) }),
  z.object({ kind: z.literal("articles"), articleIds: z.array(z.number()) }),
  z.object({ kind: z.literal("faq"), group: z.string(), title: z.string() }),
  z.object({ kind: z.literal("html"), html: z.string(), toc: z.array(TocEntrySchema) }),
]);

export const PageSchema = z.object({
  id: z.number(),
  slug: z.string(),
  url: z.string(),
  title: z.string(),
  kind: z.enum(["videos", "hub", "listing", "faq", "content"]),
  parentUrl: z.string().nullable(),
  excerpt: z.string(),
  blocks: z.array(PageBlockSchema),
  updatedAt: z.string(),
  text: z.string(),
});

export const NavItemSchema = z.object({ label: z.string(), href: z.string() });

export const RedirectSchema = z.object({ from: z.string(), to: z.string().nullable(), status: z.union([z.literal(301), z.literal(410)]), reason: z.string() });

export const SiteSchema = z.object({
  name: z.string(),
  tagline: z.string(),
  legacyOrigin: z.string(),
  exportedAt: z.string(),
  source: z.string(),
  faqGroups: z.array(z.object({ slug: z.string(), name: z.string() })),
});

export type TocEntry = z.infer<typeof TocEntrySchema>;
export type Category = z.infer<typeof CategorySchema>;
export type Tag = z.infer<typeof TagSchema>;
export type Article = z.infer<typeof ArticleSchema>;
export type Faq = z.infer<typeof FaqSchema>;
export type Page = z.infer<typeof PageSchema>;
export type PageBlock = z.infer<typeof PageBlockSchema>;
export type NavItem = z.infer<typeof NavItemSchema>;
export type Redirect = z.infer<typeof RedirectSchema>;
export type Site = z.infer<typeof SiteSchema>;
