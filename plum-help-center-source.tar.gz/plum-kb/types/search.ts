export type SearchDocType = "article" | "video" | "faq" | "category" | "page";

export type SearchDoc = {
  id: string;
  type: SearchDocType;
  title: string;
  url: string;
  /** Where it lives, e.g. "Plum POS / Configurations". */
  crumb: string;
  /** Headings, category and tag names: boosted, not displayed. */
  keywords: string;
  /** Body text used for matching and snippets (trimmed). */
  text: string;
  updatedAt?: string;
};
